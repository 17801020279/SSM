package com.ssm.mapper;

import java.util.List;


import com.ssm.po.CompanyCustom;
import com.ssm.po.CompanyQueryVo;


public interface CompanyMapperCustom {

		//登录
		public List<CompanyCustom> companyLogin(CompanyQueryVo companyQueryVo) throws Exception;

		//注册
		public void companyRegister(CompanyCustom companyCustom)throws Exception;
		
		//修改用户信息
		public CompanyCustom updateCompany(CompanyQueryVo CompanyQueryVo)throws Exception;
		
		// 用户名称查重
		public List<CompanyCustom> checkCompanyName(String companyName) throws Exception;
		
		

}
