package com.ssm.po;

import java.util.List;


/**
 * 用户的扩展类
 * @author lenovo
 *
 */
public class UserCustom extends User{
	
	
	List<DemandCustom> demandList;

	public List<DemandCustom> getDemandList() {
		return demandList;
	}

	public void setDemandList(List<DemandCustom> demandList) {
		this.demandList = demandList;
	}
	

}
