package com.ssm.po;
/**
 * 需求的包装对象类
 * @author lenovo
 *
 */
public class DemandQueryVo {
	
	private Demand demand;
	
	//为了系统可扩展性，对原始生成的po进行扩展
	private DemandCustom demandCustom;
	
	private User user;

	public Demand getDemand() {
		return demand;
	}

	public void setDemand(Demand demand) {
		this.demand = demand;
	}

	public DemandCustom getDemandCustom() {
		return demandCustom;
	}

	public void setDemandCustom(DemandCustom demandCustom) {
		this.demandCustom = demandCustom;
	}

	public User getUser() {
		return user;
	}

	public void setUser(User user) {
		this.user = user;
	}

	

}
