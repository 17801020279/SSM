package com.ssm.service;

import java.util.List;

import com.ssm.po.Type1Custom;

public interface Type1Service {
	
	// 发布需求所需列表
	public List<Type1Custom> userReleaseRequirement() throws Exception;

}
