package com.ssm.service;

public interface PublicPageService {

}
