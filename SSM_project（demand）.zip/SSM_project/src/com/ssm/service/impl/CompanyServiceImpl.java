package com.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.CompanyMapper;
import com.ssm.mapper.CompanyMapperCustom;
import com.ssm.po.CompanyCustom;
import com.ssm.po.CompanyQueryVo;
import com.ssm.service.CompanyService;

public class CompanyServiceImpl implements CompanyService{
	
	@Resource(name="companyMapperCustom")
	private CompanyMapperCustom companyMapperCustom;
	
	@Resource(name="companyMapper")
	private CompanyMapper companyMapper;

	@Override
	public CompanyCustom companyRegister(CompanyCustom companyCustom) throws Exception {
		List<CompanyCustom> list = companyMapperCustom.checkCompanyName(companyCustom.getComName());
		if(list.isEmpty()) {
			companyMapperCustom.companyRegister(companyCustom);
			return companyCustom;
		}
		else
			return null;
	}

	@Override
	public CompanyCustom companyLogin(CompanyCustom companyCustom) throws Exception {
		CompanyQueryVo companyQueryVo = new CompanyQueryVo();
		companyQueryVo.setCompanyCustom(companyCustom);
		List<CompanyCustom> list = companyMapperCustom.companyLogin(companyQueryVo);
		if(list.isEmpty())
			return null;
		else
			return list.get(0);
	}

}
