package com.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.Type1Mapper;
import com.ssm.mapper.Type1MapperCustom;
import com.ssm.po.Type1Custom;
import com.ssm.service.Type1Service;

public class Type1ServiceImpl implements Type1Service{
	
	@Resource(name="type1MapperCustom")
	private Type1MapperCustom type1MapperCustom;
	
	@Resource(name="type1Mapper")
	private Type1Mapper type1Mapper;

	@Override
	public List<Type1Custom> userReleaseRequirement() throws Exception {
		List<Type1Custom> list = type1MapperCustom.Type1AndType2();
		return list;
	}

}
