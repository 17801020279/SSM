package com.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.UserMapper;
import com.ssm.mapper.UserMapperCustom;
import com.ssm.po.UserCustom;
import com.ssm.po.UserQueryVo;
import com.ssm.service.UserService;

public class UserServiceImpl implements UserService {
	
	@Resource(name="userMapperCustom")
	private UserMapperCustom userMapperCustom;
	
	@Resource(name="userMapper")
	private UserMapper userMapper;

	@Override
	public UserCustom userRegister(UserCustom userCustom) throws Exception {
		List<UserCustom> list = userMapperCustom.checkUserName(userCustom.getUserName());
		if(list.isEmpty()) {
			userMapperCustom.userRegister(userCustom);
			return userCustom;
		}
		else
			return null;
	}

	@Override
	public UserCustom userLogin(UserCustom userCustom) throws Exception {
		UserQueryVo userQueryVo = new UserQueryVo();
		userQueryVo.setUserCustom(userCustom);
		List<UserCustom> list = userMapperCustom.userLogin(userQueryVo);
		if(list.isEmpty())
			return null;
		else
			return list.get(0);
	}

}
