package com.ssm.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.Type1Custom;
import com.ssm.po.Type2Custom;
import com.ssm.po.UserCustom;
import com.ssm.service.Type1Service;
import com.ssm.service.UserService;


@Controller //会员的Controller
@RequestMapping(value="/user")
public class UserController {
	
	@Resource(name="userService")
	private UserService userService;
	@Resource(name="type1Service")
	private Type1Service type1Service;
	
	
	// 会员注册提交后的页面
	@RequestMapping(value="/userRegisterSubmit.action")
	public String userRegisterSubmit(HttpSession session, Model model, UserCustom userCustom) throws Exception {
		UserCustom userCustom1 = userService.userRegister(userCustom);
		if(userCustom1==null) {
			String loginError = "输入的用户名已存在，请更换新的用户名";
			model.addAttribute("loginError",loginError);
			return "/jsp/register.jsp";
		}
		else {
			return "/jsp/login.jsp";
		}
	}
	
	
	// 会员登录提交后的页面
	@RequestMapping(value="/userLoginSubmit.action")
	public String userLoginSubmit(HttpSession session, Model model, UserCustom userCustom) throws Exception {
		UserCustom userCustom1 = userService.userLogin(userCustom);
		if(userCustom1==null) {
			String loginError = "输入的用户名或密码错误";
			model.addAttribute("loginError",loginError);
			return "/jsp/login.jsp";
		}
		else {
			session.setAttribute("userCustom", userCustom1);
			return "/jsp/mainPage.jsp";
		}
	}
	
	// 会员发布需求的界面
	@RequestMapping(value="/userReleaseRequirement.action")
	public String userReleaseRequirement(HttpSession session, Model model) throws Exception {
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		if(userCustom == null)
			return "/jsp/login.jsp";
		else {
			List<Type1Custom> type1Andtype2list = type1Service.userReleaseRequirement();
			// 检验是否得到type1Andtype2list
//			Type1Custom type1 = type1Andtype2list.get(1);
//			System.out.println(type1.getFirstTypeId());
//			System.out.println(type1.getTypeName());
//			Type2Custom type2 = type1.getType2Customlist().get(1);
//			System.out.println(type2.getSecTypeId());
//			System.out.println(type2.getTypeName());
//			System.out.println(type2.getTypeFirstId());
			model.addAttribute("type1Andtype2list",type1Andtype2list);
			return "/jsp/send_demand.jsp";
		}
	}
	
//	// 会员退出后的界面
//	@RequestMapping(value="/userReleaseRequirement.action")
//	public String userLogout(HttpSession session) {
//		return "/jsp/send_demand.jsp";
//	}

}