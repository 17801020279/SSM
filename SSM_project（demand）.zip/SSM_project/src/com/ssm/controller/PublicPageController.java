package com.ssm.controller;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.service.PublicPageService;

@Controller //公开页面的Controller
@RequestMapping(value="/publicPage")
public class PublicPageController {
	
	@Resource(name="publicPageService")
	private PublicPageService publicPageService;
	
	// 首页
	@RequestMapping(value="/mainPage.action")
	public String mainPage() throws Exception {
		return "/jsp/mainPage.jsp";
	}
	
	// 注册的页面
	@RequestMapping(value="/Register.action")
	public String Register() throws Exception {
		return "/jsp/register.jsp";
	}
	
	// 登录的页面
	@RequestMapping(value="/Login.action")
	public String Login() throws Exception {
		return "/jsp/login.jsp";
	}

}
