package com.ssm.controller;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.CompanyCustom;
import com.ssm.service.CompanyService;

@Controller //公司的Controller
@RequestMapping(value="/company")
public class CompanyController {
	
	@Resource(name="companyService")
	public CompanyService companyService;
	
	// 公司注册提交后的页面
	@RequestMapping(value="/companyRegisterSubmit.action")
	public String companyRegisterSubmit(HttpSession session, Model model, CompanyCustom companyCustom) throws Exception {
		CompanyCustom companyCustom1 = companyService.companyRegister(companyCustom);
		if(companyCustom1==null) {
			String loginError = "输入的公司已注册，请直接登录";
			model.addAttribute("loginError",loginError);
			return "/jsp/register.jsp";
		}
		else {
			return "/jsp/login.jsp";
		}
	}
	
	
	// 公司登录提交后的页面
	@RequestMapping(value="/companyLoginSubmit.action")
	public String companyLoginSubmit(HttpSession session, Model model, CompanyCustom companyCustom) throws Exception {
		CompanyCustom companyCustom1 = companyService.companyLogin(companyCustom);
		if(companyCustom1==null) {
			String loginError = "输入的用户名或密码错误";
			model.addAttribute("loginError",loginError);
			return "/jsp/login.jsp";
		}
		else {
			session.setAttribute("companyCustom", companyCustom1);
			return "/jsp/mainPage.jsp";
		}
	}

}
