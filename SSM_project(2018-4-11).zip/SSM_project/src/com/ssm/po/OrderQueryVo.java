package com.ssm.po;
/**
 * 订单的包装对象类
 * @author lenovo
 *
 */
public class OrderQueryVo{
	
	private Order order;
	
	private OrderCustom orderCustom;

	public Order getOrder() {
		return order;
	}

	public void setOrder(Order order) {
		this.order = order;
	}

	public OrderCustom getOrderCustom() {
		return orderCustom;
	}

	public void setOrderCustom(OrderCustom orderCustom) {
		this.orderCustom = orderCustom;
	}
	
	

}
