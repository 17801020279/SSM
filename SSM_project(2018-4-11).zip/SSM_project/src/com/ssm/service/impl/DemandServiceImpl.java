package com.ssm.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.DemandMapper;
import com.ssm.mapper.DemandMapperCustom;
import com.ssm.po.DemandCustom;
import com.ssm.po.UserCustom;
import com.ssm.service.DemandService;

public class DemandServiceImpl implements DemandService{
	
	@Resource(name="demandMapperCustom")
	private DemandMapperCustom demandMapperCustom;
	
	@Resource(name="demandMapper")
	private DemandMapper demandMapper;

	// 用户发布需求
	@Override
	public DemandCustom userAddDemand(UserCustom userCustom, DemandCustom demandCustom, String type2) throws Exception {
		Date time=new Date();
		demandCustom.setDemandTime(time);
		demandCustom.setUserId(userCustom.getUserId());
		demandMapperCustom.addDemand(demandCustom);
		return demandCustom;
	}

	@Override
	public List<DemandCustom> findDemandByDemandTitle(String demandTitle) throws Exception {
		List<DemandCustom> fuzzylist = demandMapperCustom.findDemandByDemandTitle(demandTitle);
		return fuzzylist;
	}

	@Override
	public List<DemandCustom> findLatestDemand() throws Exception {
		List<DemandCustom> list = demandMapperCustom.findLatestDemand();
		return list;
	}

}
