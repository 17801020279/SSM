package com.ssm.mapper;

import java.util.List;

import com.ssm.po.UserCustom;


public interface UserMapperCustom {

	// 登录
	public List<UserCustom> userLogin(UserCustom userCustom) throws Exception;

	// 注册
	public void userRegister(UserCustom userCustom) throws Exception;

	// 修改用户信息
	public void userUpdate(UserCustom userCustom) throws Exception;
		
	// 用户名称查重
	public List<UserCustom> checkUserName(String userName) throws Exception;
		
	// 查询用户个人信息
	public UserCustom userQuery(int userId) throws Exception;

		

}
