package com.ssm.mapper;

import java.util.List;

import com.ssm.po.OrderCustom;

public interface OrderMapperCustom {
	
	//1.添加order
	public void addOrder(OrderCustom orderCustom) throws Exception;
	
	// order查重
	public List<OrderCustom> checkOrders(OrderCustom orderCustom) throws Exception;
	
	//2.删除order
	public void deleteOrderById(int orderId) throws Exception;

    //3.查询与用户相关的所有订单
	public List<OrderCustom> findUserAllOrders(int userId) throws Exception;

    //4.查询与服务商相关的所有订单
	public List<OrderCustom> findCompanyAllOrders(int comId)throws Exception;

	
	


		
		

}
