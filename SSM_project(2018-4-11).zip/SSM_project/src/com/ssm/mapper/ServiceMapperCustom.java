package com.ssm.mapper;

import java.util.List;

import com.ssm.po.ServiceCustom;


public interface ServiceMapperCustom {
	
	// 1.服务商发布服务
	public void addService(ServiceCustom serviceCustom) throws Exception;

	// 服务查重
	public List<ServiceCustom> checkServices(ServiceCustom serviceCustom) throws Exception;
		
	// 2.删除服务根据Type2
	public void deleteServiceByType(int serviceType) throws Exception;
		
	// 3.更新服务
	public void updateServiceById(ServiceCustom serviceCustom) throws Exception;

	// 4.根据服务id查询服务
	public List<ServiceCustom> findServiceById(int serviceId) throws Exception;

	// 5.根据服务serviceTitle模糊查询
	public List<ServiceCustom> findServiceByTitle(String serviceTitle) throws Exception;

	// 6.查询服务商发布服务信息
	public List<ServiceCustom> findCompanyAllServices(int comId) throws Exception;

	// 7.根据serviceType查询服务
	public List<ServiceCustom> findServiceByType(int serviceType) throws Exception;

	// 8.返回最新插入的前10条记录
	public List<ServiceCustom> findLatestService() throws Exception;

		

		

}
