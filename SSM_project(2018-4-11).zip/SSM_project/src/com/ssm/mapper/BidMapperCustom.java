package com.ssm.mapper;

import java.util.List;

import com.ssm.po.BidCustom;

public interface BidMapperCustom  {

	//1.添加投标
	public void addBid(BidCustom bidCustom) throws Exception;
	
	//2.更新投标状态
	public void updateBidState(BidCustom bidCustom) throws Exception;
	
	//3.删除投标
	//public void deleteBidById(int bidId) throws Exception;
		
	// 4.查询与用户相关的所有投标
	public List<BidCustom> findUserAllBids(int userId) throws Exception;

	// 5.查询与服务商相关的所有投标
	public List<BidCustom> findCompanyAllBids(int comId) throws Exception;

	// 6.根据demandid查询投标
	public List<BidCustom> findBidsByDemandId(int i) throws Exception;

	// 7.根据serviceid查询投标
	public List<BidCustom> findBidsByServiceId(int i) throws Exception;

	//投标查重
	public List<BidCustom> checkBids(BidCustom bidCustom) throws Exception;



}
