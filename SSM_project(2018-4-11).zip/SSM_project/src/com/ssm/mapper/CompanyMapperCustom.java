package com.ssm.mapper;

import java.util.List;

import com.ssm.po.CompanyCustom;


public interface CompanyMapperCustom {

	// 登录
	public List<CompanyCustom> companyLogin(CompanyCustom CompanyCustom) throws Exception;

	// 注册
	public void companyRegister(CompanyCustom companyCustom) throws Exception;
		
	// 服务商密码修改
	public void companyUpdate(CompanyCustom companyCustom) throws Exception;

	// 服务商名称查重
	public List<CompanyCustom> checkCompanyName(String companyName) throws Exception;

	// 查询服务商个人信息
	public CompanyCustom companyQuery(int i) throws Exception;
		
		

}
