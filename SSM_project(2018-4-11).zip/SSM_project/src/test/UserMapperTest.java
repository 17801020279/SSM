package test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.UserMapperCustom;
import com.ssm.po.UserCustom;

public class UserMapperTest {
	private ApplicationContext applicationContext;
	private UserMapperCustom  userMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		userMapperCustom= (UserMapperCustom) applicationContext.getBean("userMapperCustom");
	}
	 
	//注册
	//@Test
	/*public void registTest() throws Exception{
		UserCustom userCustom=new UserCustom();
		userCustom.setUserName("999");
		userCustom.setUserPass("999");
		if (userMapperCustom.checkUserName(userCustom.getUserName()) != null) {
			System.out.println(userCustom.getUserName()+"用户已存在，注册失败");
		}else {
		userMapperCustom.userRegister(userCustom);
		System.out.println(userCustom.getUserName()+"用户注册成功");
		}
	}*/
	
	
	//登录
	@Test
	public void loginTest() throws Exception{
		UserCustom userCustom = new UserCustom();
		userCustom.setUserName("111");
		userCustom.setUserPass("111");
		List<UserCustom> userCustoms = userMapperCustom.userLogin(userCustom);
		System.out.println(userCustoms);
		System.out.println("用户登录成功");
	}
	
	
	// 查询
	@Test
	public void userQueryTest() throws Exception {
		UserCustom userCustom = userMapperCustom.userQuery(1);
		System.out.println(userCustom);

	}

	// 查重
	@Test
	public void checkUserNameTest() throws Exception {

		List<UserCustom> userCustoms = userMapperCustom.checkUserName("111");
		System.out.println(userCustoms);
	}

	// 修改
	@Test
	public void userUpdateTest() throws Exception {
		UserCustom userCustom = new UserCustom();
		userCustom.setUserId(1);
		userCustom.setUserPass("111");
		userMapperCustom.userUpdate(userCustom);
	}
		
	
	
	
	

}
