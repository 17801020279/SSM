package test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.ServiceMapperCustom;
import com.ssm.po.ServiceCustom;

public class ServiceMapperTest {
	private ApplicationContext applicationContext;
	private ServiceMapperCustom serviceMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		serviceMapperCustom= (ServiceMapperCustom) applicationContext.getBean("serviceMapperCustom");
	}
	 
	//服务商发布服务
	@Test
	public void addServiceTest() throws Exception{
		ServiceCustom serviceCustom=new ServiceCustom();
		/*Company company = new Company();
		company.setComId(1);*/
		serviceCustom.setComId(2);
		serviceCustom.setServiceTitle("第3333条服务");
		serviceCustom.setServiceType(3);
		serviceCustom.setServiceDetail("这是第3333条服务");
		Date date = new Date();
		serviceCustom.setServiceTime(date);
		serviceMapperCustom.addService(serviceCustom);
	}
	
	
	// 删除根据Type2
	@Test
	public void deleteServiceByTypeTest() throws Exception {
		serviceMapperCustom.deleteServiceByType(8);
	}
	
	
	//update
	@Test
	public void updateServiceByIdTest() throws Exception{
		ServiceCustom serviceCustom=new ServiceCustom();
		serviceCustom.setServiceId(3);
		serviceCustom.setServiceTitle("333333333333333333");
		serviceCustom.setServiceDetail("qwertyuiopasdfhjk");
		serviceCustom.setServiceType(1);
		Date date = new Date();
		serviceCustom.setServiceTime(date);
		serviceMapperCustom.updateServiceById(serviceCustom);
	}
			
	
	//根据id查询
		/*@Test
		public void findServiceByIdTest() throws Exception{
			serviceMapperCustom.findServiceById(1);
		}*/
		
		
		
	/*@Test
		public void findserviceByServiceTitleTset() throws Exception{
			serviceMapperCustom.findServiceByServiceTitle("3");
		}*/
		
	
		
	// 5.findServiceByServiceTitle
	@Test
		public void findServiceByServiceTitleTset() throws Exception{
		List<ServiceCustom> serviceCustoms = serviceMapperCustom.findServiceByTitle("5");
			System.out.println(serviceCustoms);		
	}
						
		
	// 6.findCompanyAndServicesResultMap
	@Test
	public void findCompanyAllServicesTest() throws Exception {

		List<ServiceCustom> serviceCustomList = serviceMapperCustom.findCompanyAllServices(3);
		System.out.println(serviceCustomList);
	}

	// 7.findServiceByType
	@Test
	public void findServiceByTypeTest() throws Exception {
		List<ServiceCustom> serviceCustomList = serviceMapperCustom.findServiceByType(1);
		System.out.println(serviceCustomList);
	}

				
		//8.findLatestService
	@Test
	public void findLatestServiceTest() throws Exception {
		List<ServiceCustom> serviceCustoms = serviceMapperCustom.findLatestService();
		System.out.println(serviceCustoms);
	}

	// 9.服务查重
	@Test
	public void checkServiceTest() throws Exception {

		ServiceCustom serviceCustom = new ServiceCustom();
		serviceCustom.setComId(1);
		serviceCustom.setServiceTitle("第333条服务");
		List<ServiceCustom> serviceCustomList = serviceMapperCustom.checkServices(serviceCustom);
		System.out.println(serviceCustomList);
	}

	
	

}
