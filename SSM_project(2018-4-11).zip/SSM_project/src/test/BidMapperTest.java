package test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.BidMapperCustom;
import com.ssm.po.BidCustom;

public class BidMapperTest {
	private ApplicationContext applicationContext;
	private BidMapperCustom bidMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		bidMapperCustom= (BidMapperCustom) applicationContext.getBean("bidMapperCustom");
	}
	 
	//添加投标 
	@Test
	public void addBidTest() throws Exception{
		BidCustom bidCustom=new BidCustom();
		bidCustom.setDemandId(1);
		bidCustom.setServiceId(5);
		bidCustom.setBidState("qwertyui成交");
		Date date = new Date();
		bidCustom.setBidTime(date);
		bidMapperCustom.addBid(bidCustom);
	}
	
	
	//删除
	/*@Test
	public void deleteBidByIdTest() throws Exception{
		bidMapperCustom.deleteBidById(2);
	}*/
	
	
	//update
	@Test
	public void updateBidStateTest() throws Exception{
		BidCustom bidCustom=new BidCustom();
		bidCustom.setBidId(5);
		bidCustom.setBidState("未成交");
		Date date = new Date();
		bidCustom.setBidTime(date);
		bidMapperCustom.updateBidState(bidCustom);
	}
		
	//4.查询与用户相关的所有投标
	@Test
	public void findUserAllBidsTest() throws Exception{
		List<BidCustom> bidCustomList = bidMapperCustom.findUserAllBids(1);
		System.out.println(bidCustomList);
	}
		
	//5.查询与服务商相关的所有投标
	@Test
	public void findCompanyAllBidsTest() throws Exception{
		List<BidCustom> bidCustomList = bidMapperCustom.findCompanyAllBids(1);
		System.out.println(bidCustomList);
	}
	
	
	//6.根据demandid查询投标
	@Test
	public void findBidsByDemandIdTest() throws Exception {
		List<BidCustom> bidCustomList = bidMapperCustom.findBidsByDemandId(1);
		System.out.println(bidCustomList);
	}
	

	//7.根据serviceid查询投标
	@Test
	public void findBidsByServiceIdTest() throws Exception {
		List<BidCustom> bidCustomList = bidMapperCustom.findBidsByServiceId(2);
		System.out.println(bidCustomList);
	}

	// 投标查重
	@Test
	public void checkBidTest() throws Exception {
		BidCustom bidCustom = new BidCustom();
		bidCustom.setDemandId(1);
		bidCustom.setServiceId(3);
		List<BidCustom> bidCustomList = bidMapperCustom.checkBids(bidCustom);
		System.out.println(bidCustomList);
	}
		
		
	
	
	

}
