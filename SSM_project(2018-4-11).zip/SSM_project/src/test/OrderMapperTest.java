package test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.OrderMapperCustom;
import com.ssm.po.OrderCustom;

public class OrderMapperTest {
	private ApplicationContext applicationContext;
	private OrderMapperCustom orderMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		orderMapperCustom= (OrderMapperCustom) applicationContext.getBean("orderMapperCustom");
	}
	 
	//服务商发布服务
	@Test
	public void addOrderTest() throws Exception{
		OrderCustom orderCustom=new OrderCustom();
		orderCustom.setDemandId(4);
		orderCustom.setServiceId(3);
		Date date = new Date();
		orderCustom.setOrderTime(date);
		orderMapperCustom.addOrder(orderCustom);
	}
	
	
	//删除order
	@Test
	public void deleteOrderByIdTest() throws Exception{
		orderMapperCustom.deleteOrderById(1);
	}
	
	//3.查询与用户相关的所有订单
	@Test
	public void findUserAllOrdersTest() throws Exception{
		List<OrderCustom> orderCustomList = orderMapperCustom.findUserAllOrders(1);
		System.out.println(orderCustomList);
	}
		
	//4.查询与服务商相关的所有订单
	@Test
	public void findCompanyAllOrdersTest() throws Exception{
		List<OrderCustom> orderCustomList = orderMapperCustom.findCompanyAllOrders(2);
		System.out.println(orderCustomList);
	}
	
	// order查重
	@Test
	public void checkOrdersTest() throws Exception {
		OrderCustom orderCustom = new OrderCustom();
		orderCustom.setDemandId(1);
		orderCustom.setServiceId(1);
		List<OrderCustom> orderCustomList = orderMapperCustom.checkOrders(orderCustom);
		System.out.println(orderCustomList);
	}	

		
		
		
	
	
	

}
