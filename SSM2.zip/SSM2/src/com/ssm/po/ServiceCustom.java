package com.ssm.po;

import java.util.List;

public class ServiceCustom extends Service {
	
	private Type2Custom type2Custom;
	private List<BidCustom> bidCustomlist; 

	public List<BidCustom> getBidCustomlist() {
		return bidCustomlist;
	}

	public void setBidCustomlist(List<BidCustom> bidCustomlist) {
		this.bidCustomlist = bidCustomlist;
	}

	public Type2Custom getType2Custom() {
		return type2Custom;
	}

	public void setType2Custom(Type2Custom type2Custom) {
		this.type2Custom = type2Custom;
	}

}
