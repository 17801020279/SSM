package com.ssm.po;

import java.util.Date;

public class Demand {
    private Integer demandId;

    private Integer userId;

    private String demandTitle;

    private Integer demandType;

    private String demandDetail;

    private Date demandTime;

    public Integer getDemandId() {
        return demandId;
    }

    public void setDemandId(Integer demandId) {
        this.demandId = demandId;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getDemandTitle() {
        return demandTitle;
    }

    public void setDemandTitle(String demandTitle) {
        this.demandTitle = demandTitle == null ? null : demandTitle.trim();
    }

    public Integer getDemandType() {
        return demandType;
    }

    public void setDemandType(Integer demandType) {
        this.demandType = demandType;
    }

    public String getDemandDetail() {
        return demandDetail;
    }

    public void setDemandDetail(String demandDetail) {
        this.demandDetail = demandDetail == null ? null : demandDetail.trim();
    }

    public Date getDemandTime() {
        return demandTime;
    }

    public void setDemandTime(Date demandTime) {
        this.demandTime = demandTime;
    }
}