package com.ssm.po;

import java.util.List;

public class Type1Custom extends Type1 {
	
	private List<Type2Custom> type2Customlist;
	
	private List<String> type2NameList;
	
	public List<Type2Custom> getType2Customlist() {
		return type2Customlist;
	}

	public void setType2Customlist(List<Type2Custom> type2Customlist) {
		this.type2Customlist = type2Customlist;
	}

	public List<String> getType2NameList() {
		return type2NameList;
	}

	public void setType2NameList(List<String> type2NameList) {
		this.type2NameList = type2NameList;
	}
	
}
