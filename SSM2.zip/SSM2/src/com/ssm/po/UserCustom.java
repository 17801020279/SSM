package com.ssm.po;

public class UserCustom extends User {
	private String userPassOld;
	
	private String userPassNew;

	public String getUserPassOld() {
		return userPassOld;
	}

	public void setUserPassOld(String userPassOld) {
		this.userPassOld = userPassOld;
	}

	public String getUserPassNew() {
		return userPassNew;
	}

	public void setUserPassNew(String userPassNew) {
		this.userPassNew = userPassNew;
	}
	
}
