package com.ssm.po;

public class BidCustom extends Bid {
	
	private String  user_name;
	
	private String  com_name;
	
	private String  demand_title;
	
	private String  service_title;
	
	private String  type1_name;
	
	private String  type2_name;

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getCom_name() {
		return com_name;
	}

	public void setCom_name(String com_name) {
		this.com_name = com_name;
	}

	public String getDemand_title() {
		return demand_title;
	}

	public void setDemand_title(String demand_title) {
		this.demand_title = demand_title;
	}

	public String getService_title() {
		return service_title;
	}

	public void setService_title(String service_title) {
		this.service_title = service_title;
	}

	public String getType1_name() {
		return type1_name;
	}

	public void setType1_name(String type1_name) {
		this.type1_name = type1_name;
	}

	public String getType2_name() {
		return type2_name;
	}

	public void setType2_name(String type2_name) {
		this.type2_name = type2_name;
	}
	
}
