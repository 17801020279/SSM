package com.ssm.po;

import java.util.List;

public class DemandCustom extends Demand {
	
	private String userName;
	private String first_type_name;
	private String second_type_Nmae;
	private Type2Custom type2Custom;
	private List<BidCustom> bidCustomlist; 
	
	public List<BidCustom> getBidCustomlist() {
		return bidCustomlist;
	}
	public void setBidCustomlist(List<BidCustom> bidCustomlist) {
		this.bidCustomlist = bidCustomlist;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFirst_type_name() {
		return first_type_name;
	}
	public void setFirst_type_name(String first_type_name) {
		this.first_type_name = first_type_name;
	}
	public String getSecond_type_Nmae() {
		return second_type_Nmae;
	}
	public void setSecond_type_Nmae(String second_type_Nmae) {
		this.second_type_Nmae = second_type_Nmae;
	}
	public Type2Custom getType2Custom() {
		return type2Custom;
	}
	public void setType2Custom(Type2Custom type2Custom) {
		this.type2Custom = type2Custom;
	}

}
