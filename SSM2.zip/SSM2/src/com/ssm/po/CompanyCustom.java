package com.ssm.po;

import java.util.List;

public class CompanyCustom extends Company{

	private String comPassOld;
	
	private String comPassNew;

	private List<ServiceCustom> serviceCustomList;

	public List<ServiceCustom> getServiceCustomList() {
		return serviceCustomList;
	}

	public void setServiceCustomList(List<ServiceCustom> serviceCustomList) {
		this.serviceCustomList = serviceCustomList;
	}

	public String getComPassOld() {
		return comPassOld;
	}

	public void setComPassOld(String comPassOld) {
		this.comPassOld = comPassOld;
	}

	public String getComPassNew() {
		return comPassNew;
	}

	public void setComPassNew(String comPassNew) {
		this.comPassNew = comPassNew;
	}

	
}
