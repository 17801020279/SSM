package com.ssm.po;

public class OrderCustom extends Order {

}
