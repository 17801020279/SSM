package com.ssm.mapper;

import java.util.List;

import com.ssm.po.Type1Custom;

public interface Type1MapperCustom {
	// 查询一级类型的列表
	public List<Type1Custom> DemandAndService1() throws Exception;
	// 根据一级类型的名称，查询一级类型的对象
	public List<Type1Custom> DemandAndService2(String type1name) throws Exception;
	// 根据类型名查id
//	public int findType1IdByName(String type1Name) throws Exception;
}
