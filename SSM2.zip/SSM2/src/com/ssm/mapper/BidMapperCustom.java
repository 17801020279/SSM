package com.ssm.mapper;

import java.util.List;

import com.ssm.po.BidCustom;

public interface BidMapperCustom  {

	// 添加投标
	public void addBid(BidCustom bidCustom) throws Exception;
	// 获取全部投标
	public List<BidCustom> findAllBid() throws Exception;
	// 根据demandid查询所有投标（查询当前用户的所有投标）
	public List<BidCustom> findAllBidByDemandid(int demandid) throws Exception;
	// 根据serviceid查询所有投标（查询当前用户的所有投标）
	public List<BidCustom> findAllBidByServiceid(int serviceid) throws Exception;
	// 根据demandId删除bid
	public void deleteBidByServiceId(int serviceid) throws Exception;
	// 更新投标状态
	//public void updateBidState(BidCustom bidCustom) throws Exception;
	
	// 删除投标
	public void deleteBidById(int bidId) throws Exception;
	
}
