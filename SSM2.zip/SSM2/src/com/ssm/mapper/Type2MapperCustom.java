package com.ssm.mapper;

import java.util.List;

import com.ssm.po.Type2Custom;

public interface Type2MapperCustom {
	
	// 根据名称查询type2
	public List<Type2Custom> SelectByName(String name) throws Exception;
	//根据type2Id名称查询name
	public int findType2IdByName(String type2Name) throws Exception; 
		
}
