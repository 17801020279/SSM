package com.ssm.mapper;

import java.util.List;

import com.ssm.po.UserCustom;

public interface UserMapperCustom {
	
	// 用户名称查重
	public List<UserCustom> checkUserName(String name) throws Exception;
	
	// 用户注册
	public void userRegister(UserCustom userCustom) throws Exception;

	// 用户登录
	public List<UserCustom> userLogin(UserCustom userCustom) throws Exception;

	// 修改用户信息
	public void updateUser(UserCustom userCustom);

}
