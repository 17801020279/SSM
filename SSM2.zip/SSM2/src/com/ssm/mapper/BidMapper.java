package com.ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.ssm.po.Bid;
import com.ssm.po.BidExample;

public interface BidMapper {
    int countByExample(BidExample example);

    int deleteByExample(BidExample example);

    int deleteByPrimaryKey(Integer bidId);

    int insert(Bid record);

    int insertSelective(Bid record);

    List<Bid> selectByExample(BidExample example);

    Bid selectByPrimaryKey(Integer bidId);

    int updateByExampleSelective(@Param("record") Bid record, @Param("example") BidExample example);

    int updateByExample(@Param("record") Bid record, @Param("example") BidExample example);

    int updateByPrimaryKeySelective(Bid record);

    int updateByPrimaryKey(Bid record);
}