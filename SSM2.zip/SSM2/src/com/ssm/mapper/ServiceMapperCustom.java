package com.ssm.mapper;

import java.util.List;

import com.ssm.po.ServiceCustom;

public interface ServiceMapperCustom {
	
	// 公司发布服务
	public void companyAddService(ServiceCustom serviceCustom) throws Exception;
	// 查询公司发布的所有服务
	public List<ServiceCustom> findCompanyAllService(int comId) throws Exception;
	//公司删除没有竞标的服务
	public void deleteServiceById(Integer serviceId) throws Exception;
	
}