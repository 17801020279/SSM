package com.ssm.mapper;

import java.util.List;

import com.ssm.po.CompanyCustom;

public interface CompanyMapperCustom {
	
	// 公司名称查重
	public List<CompanyCustom> checkCompanyName(String name) throws Exception;
	
	// 公司注册
	public void companyRegister(CompanyCustom companyCustom) throws Exception;

	// 公司登录
	public List<CompanyCustom> companyLogin(CompanyCustom companyCustom) throws Exception;
	
	 //修改公司信息
	 public void updateCompany(CompanyCustom companyCustom)throws Exception;
	
}
