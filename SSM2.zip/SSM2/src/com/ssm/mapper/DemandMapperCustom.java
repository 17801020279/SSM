package com.ssm.mapper;

import java.util.List;

import com.ssm.po.DemandCustom;

public interface DemandMapperCustom {
	
	// 用户发布需求
	public void userAddDemand(DemandCustom demandCustom) throws Exception;
	// 根据id查询发布的需求
	public DemandCustom findDemandById(int demandId) throws Exception;
	// 根据demandTitle模糊查询需求
	public List<DemandCustom> findDemandByDemandTitle(String demandTitle) throws Exception;
	// 查询最新的10条需求
	public List<DemandCustom> findLatestDemand() throws Exception;
	// 查询一个用户发布的所有需求
	public List<DemandCustom> findUserAllDemand(int userid) throws Exception;
	
	// 根据id删除需求
	public void deleteDemandById(int demandId) throws Exception;
	
//	// 2.删除需求
//	public void deleteDemandById(int demandId) throws Exception;
//	
//	// 3.更新需求
//	public void updateDemandById(DemandQueryVo demandQueryVo) throws Exception;
//	
	// 根据type2Name查询需求
	public List<DemandCustom>  findDemandByType2Id(Integer type2Id) throws Exception;
//	
	
	public  List<DemandCustom> findDemandByType2Name(String type2Name) throws Exception ;

	public  List<DemandCustom> findDemandByType1Name(String type2Name) throws Exception ;
//	
//	// 6.查询用户发布需求信息
//	public List<UserCustom> findUserAndDemandsResultMap() throws Exception;
	
}
