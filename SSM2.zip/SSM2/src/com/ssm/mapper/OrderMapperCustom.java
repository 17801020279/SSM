package com.ssm.mapper;

import java.util.List;

import com.ssm.po.OrderCustom;

public interface OrderMapperCustom {
	
	// 添加order
	public void addOrder(OrderCustom orderCustom) throws Exception;
    // 根据会员名称查询order
	public List<OrderCustom> findOrderByUserName(String userName) throws Exception;
	// 根据公司名称查询order
	public List<OrderCustom> findOrderByCompanyName(String companyName) throws Exception;
	
	// order查重
	public List<OrderCustom> checkOrders(OrderCustom orderCustom) throws Exception;
	
	//2.删除order
	public void deleteOrderById(int orderId) throws Exception;

    //3.查询与用户相关的所有订单
	public List<OrderCustom> findUserAllOrders(int userId) throws Exception;

    //4.查询与服务商相关的所有订单
	public List<OrderCustom> findCompanyAllOrders(int comId)throws Exception;

	
	


		
		

}
