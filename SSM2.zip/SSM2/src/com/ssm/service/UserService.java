package com.ssm.service;

import java.util.List;

import com.ssm.po.DemandCustom;
import com.ssm.po.OrderCustom;
import com.ssm.po.UserCustom;

public interface UserService {
	
	// 会员注册
	public UserCustom userRegister(UserCustom userCustom) throws Exception;
	// 会员登录
	public UserCustom userLogin(UserCustom userCustom) throws Exception;
	// 会员个人主页
	public List<DemandCustom> userHomePage(int userid) throws Exception;
	// 会员下单
	public void addOrder(OrderCustom orderCustom) throws Exception;
	// 会员所有的订单
	public List<OrderCustom> showOrder(UserCustom userCustom) throws Exception;
	//会员删除没有被投标的demand
	public void deleteDemand(Integer demandId) throws Exception;
	//会员修改个人信息
	public String updateUserInfo(UserCustom userCustom,String userPass);
}