package com.ssm.service;

import java.util.List;

import com.ssm.po.DemandCustom;
import com.ssm.po.UserCustom;

public interface DemandService {
	
	// 用户发布需求
	public DemandCustom userAddDemand(UserCustom userCustom, DemandCustom demandCustom, String type2) throws Exception;
	
	// 根据demandTitle模糊查询需求
	public List<DemandCustom> findDemandByDemandTitle(String demandTitle) throws Exception;
	
	// 查询最新的10条需求
	public List<DemandCustom> findLatestDemand() throws Exception;

	//按照type2Name查询的需求
	public List<DemandCustom> findDemandByType2Id(Integer type2Id) throws Exception;
	public  List<DemandCustom> findDemandByType2Name(String type2Name) throws Exception ;
	
	public  List<DemandCustom> findDemandByType1Name(String type2Name) throws Exception ;

	
}
