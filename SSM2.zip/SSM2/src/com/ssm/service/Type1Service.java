package com.ssm.service;

import java.util.List;

import com.ssm.po.Type1Custom;

public interface Type1Service {
	
	// 查询一级类型的列表
	public List<Type1Custom> DemandAndService1() throws Exception;
	// 根据一级类型的名称，查询二级类型的名称列表
	public List<String> DemandAndService2(String name) throws Exception;

}
