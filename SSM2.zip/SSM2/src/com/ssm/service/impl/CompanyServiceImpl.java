package com.ssm.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.BidMapperCustom;
import com.ssm.mapper.CompanyMapper;
import com.ssm.mapper.CompanyMapperCustom;
import com.ssm.mapper.DemandMapperCustom;
import com.ssm.mapper.OrderMapperCustom;
import com.ssm.mapper.ServiceMapperCustom;
import com.ssm.po.BidCustom;
import com.ssm.po.CompanyCustom;
import com.ssm.po.DemandCustom;
import com.ssm.po.OrderCustom;
import com.ssm.po.ServiceCustom;
import com.ssm.service.CompanyService;

public class CompanyServiceImpl implements CompanyService{
	
	@Resource(name="companyMapperCustom")
	private CompanyMapperCustom companyMapperCustom;
	
	@Resource(name="companyMapper")
	private CompanyMapper companyMapper;
	
	@Resource(name="demandMapperCustom")
	private DemandMapperCustom demandMapperCustom;
	
	@Resource(name="serviceMapperCustom")
	private ServiceMapperCustom serviceMapperCustom;
	
	@Resource(name="bidMapperCustom")
	private BidMapperCustom bidMapperCustom;

	@Resource(name="orderMapperCustom")
	private OrderMapperCustom orderMapperCustom;
	@Override
	public CompanyCustom companyRegister(CompanyCustom companyCustom) throws Exception {
		List<CompanyCustom> list = companyMapperCustom.checkCompanyName(companyCustom.getComName());
		if(list.isEmpty()) {
			companyMapperCustom.companyRegister(companyCustom);
			return companyCustom;
		}
		else
			return null;
	}

	@Override
	public CompanyCustom companyLogin(CompanyCustom companyCustom) throws Exception {
		List<CompanyCustom> list = companyMapperCustom.companyLogin(companyCustom);
		if(list.isEmpty())
			return null;
		else
			return list.get(0);
	}

	@Override
	public BidCustom addBid(int comId, int demandId) throws Exception {
		DemandCustom demandCustom = demandMapperCustom.findDemandById(demandId);
		List<ServiceCustom> list1 = serviceMapperCustom.findCompanyAllService(comId);
		for(ServiceCustom serviceCustom:list1 ) {
			if(demandCustom.getDemandType()==serviceCustom.getServiceType())
			{
				List<BidCustom> list2 = bidMapperCustom.findAllBid();
				for(BidCustom bidCustom:list2) {
					if(bidCustom.getDemandId()==demandId&&bidCustom.getServiceId()==serviceCustom.getServiceId()) {
						return null;
					}
				}
				Date time=new Date();
				BidCustom bidCustom = new BidCustom();
				bidCustom.setDemandId(demandId);
				bidCustom.setServiceId(serviceCustom.getServiceId());
				bidCustom.setBidTime(time);
				bidCustom.setBidState("进行中");
				bidMapperCustom.addBid(bidCustom);
				return bidCustom;
			}
		}
		return null;
	}

	@Override
	public List<ServiceCustom> companyHomePage(int companyid) throws Exception {
		List<ServiceCustom> serviceCustomlist = serviceMapperCustom.findCompanyAllService(companyid);
		for(ServiceCustom serviceCustom:serviceCustomlist) {
			List<BidCustom> bidCustomlist = bidMapperCustom.findAllBidByServiceid(serviceCustom.getServiceId());
			serviceCustom.setBidCustomlist(bidCustomlist);
		}
		return serviceCustomlist;
	}

	//根据公司名成查询订单
	@Override
	public List<OrderCustom> findOrderByCompanyName(String name) throws Exception {
		// TODO Auto-generated method stub
		List<OrderCustom> orderCustomList = orderMapperCustom.findOrderByCompanyName(name);
		return orderCustomList;
	}

	//在服务商的个人中心，根据bidId取消bid,
	@Override
	public void cancelBid(Integer bidId) throws Exception {
		// TODO Auto-generated method stub
		bidMapperCustom.deleteBidById(bidId);
	}

	@Override
	public void deleteService(Integer serviceId) throws Exception {
		// TODO Auto-generated method stub
		serviceMapperCustom.deleteServiceById(serviceId);
	}

	@Override
	public String updatePerInfo(CompanyCustom companyCustom,String comPass) throws Exception {
		// TODO Auto-generated method stub
		if(companyCustom.getComPass().equals(comPass)) {
			if (companyCustom.getComPassOld().equals(companyCustom.getComPassNew())) {
				companyMapperCustom.updateCompany(companyCustom);
				return "修改成功";
			}else {
				return "操作有误";
			}
		}else {
			return "操作有误";
		}
		
	}
}
