package com.ssm.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.BidMapperCustom;
import com.ssm.mapper.DemandMapperCustom;
import com.ssm.mapper.OrderMapperCustom;
import com.ssm.mapper.UserMapper;
import com.ssm.mapper.UserMapperCustom;
import com.ssm.po.BidCustom;
import com.ssm.po.DemandCustom;
import com.ssm.po.OrderCustom;
import com.ssm.po.UserCustom;
import com.ssm.service.UserService;

public class UserServiceImpl implements UserService {
	
	@Resource(name="userMapperCustom")
	private UserMapperCustom userMapperCustom;
	
	@Resource(name="userMapper")
	private UserMapper userMapper;
	
	@Resource(name="demandMapperCustom")
	private DemandMapperCustom demandMapperCustom;
	
	@Resource(name="bidMapperCustom")
	private BidMapperCustom bidMapperCustom;

	@Resource(name="orderMapperCustom")
	private OrderMapperCustom orderMapperCustom;
	
	@Override
	public UserCustom userRegister(UserCustom userCustom) throws Exception {
		List<UserCustom> list = userMapperCustom.checkUserName(userCustom.getUserName());
		if(list.isEmpty()) {
			userMapperCustom.userRegister(userCustom);
			return userCustom;
		}
		else
			return null;
	}

	@Override
	public UserCustom userLogin(UserCustom userCustom) throws Exception {
		List<UserCustom> list = userMapperCustom.userLogin(userCustom);
		if(list.isEmpty())
			return null;
		else
			return list.get(0);
	}

	@Override
	public List<DemandCustom> userHomePage(int userid) throws Exception {
		List<DemandCustom> demandCustomlist = demandMapperCustom.findUserAllDemand(userid);
		for(DemandCustom demandCustom:demandCustomlist) {
			List<BidCustom> bidCustomlist = bidMapperCustom.findAllBidByDemandid(demandCustom.getDemandId());
			demandCustom.setBidCustomlist(bidCustomlist);
		}
		return demandCustomlist;
	}

	@Override
	public void addOrder(OrderCustom orderCustom) throws Exception {
		Date time = new Date();
		orderCustom.setOrderTime(time);
		orderMapperCustom.addOrder(orderCustom);
		bidMapperCustom.deleteBidByServiceId(orderCustom.getDemandId());
		demandMapperCustom.deleteDemandById(orderCustom.getDemandId());
	}

	@Override
	public List<OrderCustom> showOrder(UserCustom userCustom) throws Exception {
		List<OrderCustom> orderCustomlist = orderMapperCustom.findOrderByUserName(userCustom.getUserName());
		return orderCustomlist;
	}

	@Override
	public void deleteDemand(Integer demandId) throws Exception {
		// TODO Auto-generated method stub
		demandMapperCustom.deleteDemandById(demandId);
	}

	@Override
	public String updateUserInfo(UserCustom userCustom, String userPass) {
		if(userCustom.getUserPass().equals(userPass)) {
			if (userCustom.getUserPassOld().equals(userCustom.getUserPassNew())) {
				userMapperCustom.updateUser(userCustom);
				return "修改成功";
			}else {
				return "操作有误";
			}
		}else {
			return "操作有误";
		}
	}
}
