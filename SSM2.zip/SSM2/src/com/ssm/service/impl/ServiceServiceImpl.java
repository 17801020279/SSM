package com.ssm.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import com.ssm.mapper.ServiceMapper;
import com.ssm.mapper.ServiceMapperCustom;
import com.ssm.po.CompanyCustom;
import com.ssm.po.ServiceCustom;
import com.ssm.service.ServiceService;

public class ServiceServiceImpl implements ServiceService{
	
	@Resource(name="serviceMapperCustom")
	private ServiceMapperCustom serviceMapperCustom;
	
	@Resource(name="serviceMapper")
	private ServiceMapper serviceMapper;

	@Override
	public ServiceCustom companyAddService(CompanyCustom companyCustom, ServiceCustom serviceCustom, String type2) throws Exception {
		Date time=new Date();
		serviceCustom.setServiceTime(time);
		serviceCustom.setComId(companyCustom.getComId());
		serviceMapperCustom.companyAddService(serviceCustom);
		return serviceCustom;
	}

}
