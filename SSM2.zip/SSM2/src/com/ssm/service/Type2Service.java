package com.ssm.service;

import com.ssm.po.Type2Custom;

public interface Type2Service {
	
	public Type2Custom SelectByName(String name) throws Exception;

	public int findType2IdByName(String type2Name) throws Exception;
}
