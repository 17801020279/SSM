package com.ssm.service;

import java.util.List;

import com.ssm.po.BidCustom;
import com.ssm.po.CompanyCustom;
import com.ssm.po.OrderCustom;
import com.ssm.po.ServiceCustom;

public interface CompanyService {
	
	// 公司注册
	public CompanyCustom companyRegister(CompanyCustom companyCustom) throws Exception;
	// 公司登录
	public CompanyCustom companyLogin(CompanyCustom companyCustom) throws Exception;
	// 公司投标
	public BidCustom addBid(int comId, int demandId) throws Exception;
	// 公司个体主页
	public List<ServiceCustom> companyHomePage(int companyid) throws Exception;
	//公司订单
	public List<OrderCustom> findOrderByCompanyName(String name) throws Exception;
	//公司取消bid
	public void cancelBid(Integer bidId) throws Exception;
	//公司删除没有竞标的服务
	public void deleteService(Integer serviceId) throws Exception;
	//公司修改
	public String updatePerInfo(CompanyCustom companyCustom,String comPass) throws Exception;
}
