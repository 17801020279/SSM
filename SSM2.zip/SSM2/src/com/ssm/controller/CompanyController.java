package com.ssm.controller;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.po.BidCustom;
import com.ssm.po.CompanyCustom;
import com.ssm.po.OrderCustom;
import com.ssm.po.ServiceCustom;
import com.ssm.po.Type1Custom;
import com.ssm.po.Type2Custom;
import com.ssm.po.UserCustom;
import com.ssm.service.CompanyService;
import com.ssm.service.ServiceService;
import com.ssm.service.Type1Service;
import com.ssm.service.Type2Service;

@Controller //公司的Controller
@RequestMapping(value="/company")
public class CompanyController {
	
	@Resource(name="companyService")
	public CompanyService companyService;
	@Resource(name="type1Service")
	private Type1Service type1Service;
	@Resource(name="type2Service")
	private Type2Service type2Service;
	@Resource(name="serviceService")
	private ServiceService serviceService;
	
	// 公司注册提交后的页面
	@RequestMapping(value="/companyRegisterSubmit.action")
	public String companyRegisterSubmit(HttpSession session, Model model, CompanyCustom companyCustom) throws Exception {
		companyCustom = companyService.companyRegister(companyCustom);
		if(companyCustom==null) {
			String loginError = "输入的公司已注册，请直接登录";
			model.addAttribute("loginError",loginError);
			return "/jsp/register.jsp";
		}
		else {
			return "/jsp/login.jsp";
		}
	}
	
	
	// 公司登录提交后的页面
	@RequestMapping(value="/companyLoginSubmit.action")
	public String companyLoginSubmit(CompanyCustom companyCustom,String comPass, HttpSession session, Model model) throws Exception {
		companyCustom = companyService.companyLogin(companyCustom);
		
		if(companyCustom==null) {
			String loginError = "输入的用户名或密码错误";
			model.addAttribute("loginError",loginError);
			return "/jsp/login.jsp";
		}
		else {
			companyCustom.setComPass(comPass);
			session.setAttribute("companyCustom", companyCustom);
			return "/publicPage/mainPage.action";
		}
	}
	
	
	// 公司发布服务，一级需求的list
	@RequestMapping(value="/companyAddService.action")
	public String companyAddService(HttpSession session, Model model) throws Exception {
			List<Type1Custom> type1list = type1Service.DemandAndService1();
			model.addAttribute("type1list",type1list);
			return "/jsp/send_service.jsp";
	}
	
	
	// 公司发布服务，二级需求的list
	@RequestMapping(value="/companyAddService2.action")
	public @ResponseBody List<String> companyAddService2(String type1) throws Exception {
		return type1Service.DemandAndService2(type1);
	}
	
	
	// 会员发布服务提交后的界面
	@RequestMapping(value="/companyReleaseServiceSubmit.action")
	public String companyReleaseServiceSubmit(HttpSession session, Model model, ServiceCustom serviceCustom, String type2) throws Exception {
		CompanyCustom companyCustom = (CompanyCustom) session.getAttribute("companyCustom");
		//得到二级分类记录
		Type2Custom type2Custom = type2Service.SelectByName(type2);
		//给服务设置分类
		serviceCustom.setServiceType(type2Custom.getSecTypeId());
		ServiceCustom serviceCustom1 = serviceService.companyAddService(companyCustom, serviceCustom, type2);
		return "/jsp/mainCenter.jsp";
	}
	
	// 公司投标
	@RequestMapping(value="/addBid.action",method= {RequestMethod.GET})
	@ResponseBody
	public List<String> addBid(Integer demandId,Model model,  HttpSession session) throws Exception {
		CompanyCustom companyCustom = (CompanyCustom) session.getAttribute("companyCustom");
		BidCustom bidCustom = companyService.addBid(companyCustom.getComId(), demandId);
		String addBidMessage;
		List<String> mess = new ArrayList<String>();
		if(bidCustom==null) {
			addBidMessage = "投标失败";
		}
		else {
			addBidMessage = "投标成功";
		}
		mess.add(addBidMessage);
		return mess;
	}
	
	// 公司个体主页,查看所有服务
	@RequestMapping(value="/companyHomePage.action")
	@ResponseBody
	public List<ServiceCustom> companyHomePage(HttpSession session,HttpServletRequest request, Model model) throws Exception {
		
		CompanyCustom companyCustom = (CompanyCustom) session.getAttribute("companyCustom");
		List<ServiceCustom> companyserviceCustomlist = companyService.companyHomePage(companyCustom.getComId());
		return companyserviceCustomlist;
	}

	@RequestMapping("/showOrder")
	@ResponseBody
	public List<OrderCustom>  showOrder(HttpSession session) throws Exception {
		CompanyCustom comCustom = (CompanyCustom) session.getAttribute("companyCustom");
		List<OrderCustom> orderCustomlist = companyService.findOrderByCompanyName(comCustom.getComName());
		return orderCustomlist;
	}
	@RequestMapping("/cancelOrder")
	@ResponseBody
	public List<String> cancelOrder(Integer bidId) throws Exception{
		companyService.cancelBid(bidId);
		List<String> sList = new ArrayList<String>();
		sList.add("撤销成功");
		return sList;
	}
	
	@RequestMapping("/deleteDemand.action")
	@ResponseBody
	public List<String> deleteDemand(Integer bidNum,Integer serviceId) throws Exception{
		List<String> sList = new ArrayList<String>();
		if (bidNum==0) {
			//直接根据demandId删除
			companyService.deleteService(serviceId);
			sList.add("删除成功");
			return sList;
		}else {
			//不能直接删除，因为还有关联的bid
			sList.add("不能直接删除，因为还有关联的bid");
			return sList;
		}
	}
	
	@RequestMapping("/changeBasic.action")
	public String changeBasic(CompanyCustom companyCustom, HttpSession session) throws Exception{
		CompanyCustom companyCustom2 =(CompanyCustom )session.getAttribute("companyCustom"); 
		companyCustom.setComId(companyCustom2.getComId());
		String callback = companyService.updatePerInfo(companyCustom,companyCustom2.getComPass());
		if (callback.equals("修改成功")) {
			return "redirect:/publicPage/quit.action";
		}else {
			return null;
		}
	}
}
