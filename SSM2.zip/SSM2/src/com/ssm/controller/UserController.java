package com.ssm.controller;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.beans.BeanUtils;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.po.CompanyCustom;
import com.ssm.po.DemandCustom;
import com.ssm.po.Order;
import com.ssm.po.OrderCustom;
import com.ssm.po.Type1Custom;
import com.ssm.po.Type2Custom;
import com.ssm.po.User;
import com.ssm.po.UserCustom;
import com.ssm.service.DemandService;
import com.ssm.service.Type1Service;
import com.ssm.service.Type2Service;
import com.ssm.service.UserService;


@Controller //会员的Controller
@RequestMapping(value="/user")
public class UserController {
	
	@Resource(name="userService")
	private UserService userService;
	@Resource(name="type1Service")
	private Type1Service type1Service;
	@Resource(name="type2Service")
	private Type2Service type2Service;
	@Resource(name="demandService")
	private DemandService demandService;
	// 会员注册提交后的页面
	@RequestMapping(value="/userRegisterSubmit.action")
	public String userRegisterSubmit(HttpSession session, Model model, UserCustom userCustom) throws Exception {
		UserCustom userCustom1 = userService.userRegister(userCustom);
		if(userCustom1==null) {
			String loginError = "输入的用户名已存在，请更换新的用户名";
			model.addAttribute("loginError",loginError);
			return "/jsp/register.jsp";
		}
		else {
			return "/jsp/login.jsp";
		}
	}
	
	
	// 会员登录提交后的页面
	@RequestMapping(value="/userLoginSubmit.action")
	public String userLoginSubmit(UserCustom userCustom, String userPass, HttpSession session, Model model) throws Exception {
		UserCustom userCustom1 = userService.userLogin(userCustom);
		if(userCustom1==null) {
			String loginError = "输入的用户名或密码错误";
			model.addAttribute("loginError",loginError);
			return "/jsp/login.jsp";
		}
		else {
			userCustom1.setUserPass(userPass);
			session.setAttribute("userCustom", userCustom1);
			return "/publicPage/mainPage.action";
		}
	}
	
	
	// 会员发布需求，一级需求的list
	@RequestMapping(value="/userAddDemand.action")
	public String userAddDemand(HttpSession session, Model model) throws Exception {
		List<Type1Custom> type1list = type1Service.DemandAndService1();
		model.addAttribute("type1list",type1list);
		return "/jsp/send_demand.jsp";
	}
	
	
	// 会员发布需求，二级需求的list
	@RequestMapping(value="/userAddDemand2.action")
	public @ResponseBody List<String> userAddDemand2(String type1) throws Exception {
		return type1Service.DemandAndService2(type1);
	}
	
	
	// 会员发布需求提交后的界面
	@RequestMapping(value="/userReleaseRequirementSubmit.action")
	public String userReleaseRequirementSubmit(HttpSession session, Model model, DemandCustom demandCustom, String type2) throws Exception {
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		Type2Custom type2Custom = type2Service.SelectByName(type2);
		demandCustom.setDemandType(type2Custom.getSecTypeId());
		DemandCustom demandCustom1 = demandService.userAddDemand(userCustom, demandCustom, type2);
		model.addAttribute("demandCustom",demandCustom1);
		return "redirect:/publicPage/mainPage.action";
	}
	
	// 用户个人主页
	@RequestMapping(value="/userHomePage.action")
	@ResponseBody
	public List<DemandCustom> userHomePage(HttpSession session, Model model) throws Exception {
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		List<DemandCustom> userdemandCustomlist = userService.userHomePage(userCustom.getUserId());
		model.addAttribute("userdemandCustomlist",userdemandCustomlist);
		return userdemandCustomlist;
	}
	
	
//	// 会员退出后的界面
//	@RequestMapping(value="/userReleaseRequirement.action")
//	public String userLogout(HttpSession session) {
//		return "/jsp/send_demand.jsp";
//	}
	
	@RequestMapping(value="/addOrder.action",method= {RequestMethod.POST,RequestMethod.GET})
	@ResponseBody
	public List<OrderCustom> addOrder(@RequestBody OrderCustom orderCustom,HttpSession session) throws Exception {
		System.out.println(orderCustom.getDemandId());
		
		userService.addOrder(orderCustom);
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		List<OrderCustom> orderCustomlist = userService.showOrder(userCustom);
		return orderCustomlist;
	}
	
	@RequestMapping("/showOrder")
	@ResponseBody
	public List<OrderCustom>  showOrder(HttpSession session) throws Exception {
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		List<OrderCustom> orderCustomlist = userService.showOrder(userCustom);
		return orderCustomlist;
	}
	
	@RequestMapping("/deleteDemand.action")
	@ResponseBody
	public List<String> deleteDemand(Integer bidNum,Integer demandId) throws Exception{
		List<String> sList = new ArrayList<String>();
		if (bidNum==0) {
			//直接根据demandId删除
			userService.deleteDemand(demandId);
			sList.add("删除成功");
			return sList;
		}else {
			//不能直接删除，因为还有关联的bid
			sList.add("不能直接删除，因为还有关联的bid");
			return sList;
		}
	}
	
	@RequestMapping("/changeBasic.action")
	public String changeBasic(UserCustom userCustom, HttpSession session) throws Exception{
		UserCustom userCustom2 =(UserCustom )session.getAttribute("userCustom"); 
		userCustom.setUserId(userCustom2.getUserId());
		String callback = userService.updateUserInfo(userCustom,userCustom2.getUserPass());
		if (callback.equals("修改成功")) {
			return "redirect:/publicPage/quit.action";
		}else {
			return "/jsp/usermainCenter.jsp";
		}
	}
}