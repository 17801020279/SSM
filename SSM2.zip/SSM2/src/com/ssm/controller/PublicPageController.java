package com.ssm.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.po.DemandCustom;
import com.ssm.po.Type1Custom;
import com.ssm.service.DemandService;
import com.ssm.service.PublicPageService;
import com.ssm.service.Type1Service;
import com.ssm.service.Type2Service;

@Controller //公开页面的Controller
@RequestMapping(value="/publicPage")
public class PublicPageController {
	
	@Resource(name="publicPageService")
	private PublicPageService publicPageService;
	@Resource(name="demandService")
	private DemandService demandService;
	@Resource(name="type1Service")
	private Type1Service type1Service;
	@Resource(name="type2Service")
	private Type2Service type2Service;
	
	// 首页
	@RequestMapping(value="/mainPage.action")
	public String mainPage(Model model,HttpServletRequest request) throws Exception {
		List<DemandCustom> demandlist = demandService.findLatestDemand();
		request.setAttribute("list", demandlist);
		if (request.getAttribute("type1list_p")!=null) {
			return "/jsp/mainDemand.jsp";
		} else if (request.getAttribute("type1list_s")!=null) {
			return "/jsp/mainService.jsp";
		}else {
			return "/jsp/mainPage.jsp";
		}
	}
	
	// 注册的页面
	@RequestMapping(value="/Register.action")
	public String Register() throws Exception {
		return "/jsp/register.jsp";
	}
	
	// 登录的页面
	@RequestMapping(value="/Login.action")
	public String Login() throws Exception {
		return "/jsp/login.jsp";
	}
	
	// 根据demandTitle模糊查询需求提交后的页面
	@RequestMapping(value="/fuzzySearchDemandSubmit.action")
	public String fuzzySearchDemandSubmit(Model model, String demandTitle) throws Exception {
		List<DemandCustom> fuzzylist = demandService.findDemandByDemandTitle(demandTitle);
		model.addAttribute("fuzzylist", fuzzylist);
		return null;
	}
	
	@RequestMapping(value="/quit.action")
	public String quit(HttpSession session) throws Exception {
		if (session.getAttribute("userCustom")!=null) {
			session.removeAttribute("userCustom");
		} else if (session.getAttribute("companyCustom")!=null) {
			session.removeAttribute("companyCustom");
		}
		return "redirect:Login.action";
	}
	
	//需求大厅 按类别查询 需求
	@RequestMapping("/demandHall.action")
	public String demandHall(HttpServletRequest request) throws Exception {
		List<Type1Custom> type1list = type1Service.DemandAndService1();
		for (Type1Custom type1Custom : type1list) {
			type1Custom.setType2NameList(type1Service.DemandAndService2(type1Custom.getTypeName()));
		}
		request.setAttribute("type1list_p", type1list);
		return "forward:mainPage.action";
	}
	
	//二级类型查询需求
	@RequestMapping("/findDemandByName2.action")
	@ResponseBody
	public List<DemandCustom> findDemandByName2(String type2Name) throws Exception{
		List<DemandCustom> demandCustomList = demandService.findDemandByType2Name(type2Name);
		return demandCustomList;
	}
	
	//一级和二级一起查需求
	@RequestMapping("/findDemandByName1.action")
	@ResponseBody
	public List<DemandCustom> findDemandByName1(String type1Name) throws Exception{
		List<DemandCustom> demandCustomList = demandService.findDemandByType1Name(type1Name);
		return demandCustomList;
	}
	
	//服务大厅 按类别查询 服务
	@RequestMapping("/serviceHall.action")
	public String serviceHall(HttpServletRequest request) throws Exception {
		List<Type1Custom> type1list = type1Service.DemandAndService1();
		for (Type1Custom type1Custom : type1list) {
			type1Custom.setType2NameList(type1Service.DemandAndService2(type1Custom.getTypeName()));
		}
		request.setAttribute("type1list_s", type1list);
		return "forward:mainPage.action";
	}
		
	
}
