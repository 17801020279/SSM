package test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.BidMapperCustom;
import com.ssm.po.Demand;
import com.ssm.po.BidCustom;
import com.ssm.po.BidQueryVo;

public class BidMapperTest {
	private ApplicationContext applicationContext;
	private BidMapperCustom bidMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		bidMapperCustom= (BidMapperCustom) applicationContext.getBean("bidMapperCustom");
	}
	 
	//用户发布需求
	@Test
	public void addBidTest() throws Exception{
		BidCustom bidCustom=new BidCustom();
		bidCustom.setDemandId(4);
		bidCustom.setServiceId(3);
		bidCustom.setBidState("未成交");
		Date date = new Date();
		bidCustom.setBidTime(date);
		bidMapperCustom.addBid(bidCustom);
	}
	
	
	//删除
	@Test
	public void deleteBidByIdTest() throws Exception{
		bidMapperCustom.deleteBidById(2);
	}
	
	
	//update
	@Test
	public void updateBidStateTest() throws Exception{
		BidCustom bidCustom=new BidCustom();
		bidCustom.setBidId(5);
		bidCustom.setBidState("已成交");
		Date date = new Date();
		bidCustom.setBidTime(date);
		bidMapperCustom.updateBidState(bidCustom);
	}
			
	
		
		
		
		
	
	
	

}
