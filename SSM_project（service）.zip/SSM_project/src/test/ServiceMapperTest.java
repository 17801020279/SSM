package test;

import java.util.Date;
import java.util.List;

import javax.mail.search.DateTerm;
import javax.print.attribute.standard.DateTimeAtCompleted;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.DemandMapperCustom;
import com.ssm.mapper.ServiceMapperCustom;
import com.ssm.po.Company;
import com.ssm.po.CompanyCustom;
import com.ssm.po.Demand;
import com.ssm.po.DemandCustom;
import com.ssm.po.DemandQueryVo;
import com.ssm.po.ServiceCustom;
import com.ssm.po.ServiceQueryVo;
import com.ssm.po.User;

public class ServiceMapperTest {
	private ApplicationContext applicationContext;
	private ServiceMapperCustom serviceMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		serviceMapperCustom= (ServiceMapperCustom) applicationContext.getBean("serviceMapperCustom");
	}
	 
	//服务商发布服务
	@Test
	public void addServiceTest() throws Exception{
		ServiceCustom serviceCustom=new ServiceCustom();
		/*Company company = new Company();
		company.setComId(1);*/
		serviceCustom.setComId(2);
		serviceCustom.setServiceTitle("第3333条服务");
		serviceCustom.setServiceType(3);
		serviceCustom.setServiceDetail("这是第3333条服务");
		Date date = new Date();
		serviceCustom.setServiceTime(date);
		serviceMapperCustom.addService(serviceCustom);
	}
	
	
	//删除
	@Test
	public void deleteServiceByIdTest() throws Exception{
		serviceMapperCustom.deleteServiceById(4);
	}
	
	
	//update
	@Test
	public void updateServiceByIdTest() throws Exception{
		ServiceCustom serviceCustom=new ServiceCustom();
		serviceCustom.setServiceId(3);
		serviceCustom.setServiceTitle("第333条服务");
		serviceCustom.setServiceDetail("这是第333条服务");
		serviceCustom.setServiceType(1);
		Date date = new Date();
		serviceCustom.setServiceTime(date);
		serviceMapperCustom.updateServiceById(serviceCustom);
	}
			
	
	//根据id查询
		@Test
		public void findServiceByIdTest() throws Exception{
			serviceMapperCustom.findServiceById(1);
		}
		
		
		
		@Test
		public void findserviceByServiceTitleTset() throws Exception{
			serviceMapperCustom.findServiceByServiceTitle("3");
		}
		
	
		
		//5.findServiceByServiceTitle
		@Test
		public void findServiceByServiceTitleTset() throws Exception{
			List<ServiceCustom> serviceCustoms=serviceMapperCustom.findServiceByServiceTitle("33");
			System.out.println(serviceCustoms);		
		}
						
		
	
		//8.findLatestService
		@Test
		public void findLatestServiceTest() throws Exception{
			List<ServiceCustom> serviceCustoms=serviceMapperCustom.findLatestService();
			System.out.println(serviceCustoms);	
		}

	
	

}
