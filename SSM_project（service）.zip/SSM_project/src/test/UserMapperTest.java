package test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.UserMapperCustom;
import com.ssm.po.User;
import com.ssm.po.UserCustom;

public class UserMapperTest {
	private ApplicationContext applicationContext;
	private UserMapperCustom  userMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		userMapperCustom= (UserMapperCustom) applicationContext.getBean("userMapperCustom");
	}
	 
	//注册
	//@Test
	/*public void registTest() throws Exception{
		UserCustom userCustom=new UserCustom();
		userCustom.setUserName("999");
		userCustom.setUserPass("999");
		if (userMapperCustom.checkUserName(userCustom.getUserName()) != null) {
			System.out.println(userCustom.getUserName()+"用户已存在，注册失败");
		}else {
		userMapperCustom.userRegister(userCustom);
		System.out.println(userCustom.getUserName()+"用户注册成功");
		}
	}*/
	
	
	//登录
	@Test
	public void loginTest() throws Exception{
		//userMapperCustom.loginUser("123","123");
		System.out.println(userMapperCustom);
		System.out.println("用户登录成功");
	}
	
	
		
	
	
	
	

}
