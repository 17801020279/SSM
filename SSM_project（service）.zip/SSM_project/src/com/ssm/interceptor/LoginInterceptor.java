package com.ssm.interceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.web.servlet.HandlerInterceptor;
import org.springframework.web.servlet.ModelAndView;

import com.ssm.po.CompanyCustom;
import com.ssm.po.UserCustom;

public class LoginInterceptor implements HandlerInterceptor {
	
	@Override
	public boolean preHandle(HttpServletRequest request,HttpServletResponse response,
								Object handler) throws Exception {
		// 获取url，判断url是否为公开的url，如果是就放行
		// 公开的url：首页、注册页面、注册提交后的页面、登录页面、登录提交后的页面......
		// 实际开发中要将公开地址写到配置文件中
		String url = request.getRequestURI();
		if(url.indexOf("mainPage.action")>=0 || url.indexOf("Register.action")>=0 || url.indexOf("Login.action")>=0 || url.indexOf("userRegisterSubmit.action")>=0 || url.indexOf("userLoginSubmit.action")>=0 || url.indexOf("companyRegisterSubmit.action")>=0 || url.indexOf("companyLoginSubmit.action")>=0){
			return true;
		}
		// 获取session，判断用户是否已登录，如果已登录就放行
		HttpSession session  = request.getSession();
		UserCustom userCustom = (UserCustom) session.getAttribute("userCustom");
		if(userCustom != null){
			return true;
		}
		// 获取session，判断公司是否已登录，如果已登录就放行
		CompanyCustom companyCustom = (CompanyCustom) session.getAttribute("companyCustom");
		if(companyCustom != null){
			return true;
		}
		// 如果未登录就不放行，直接跳转到登录页面（这里没有modelAndView）
		request.getRequestDispatcher("/jsp/login.jsp").forward(request, response);
		return false;
	}

	// postHandle：在开始执行Handler中的方法、返回modelAndView之前执行
	// 可以将共用的model数据（例如菜单）添加到视图，也可以统一指定jsp页面
	@Override
	public void postHandle(HttpServletRequest request,HttpServletResponse response,
							Object handler,ModelAndView modelAndView) throws Exception {
		
	}

	// afterCompletion：在执行完Handler中的方法之后执行
	// 可以进行统一异常管理和统一日志管理
	@Override
	public void afterCompletion(HttpServletRequest request,HttpServletResponse response,
								Object handler,Exception ex) throws Exception {
		
	}

}
