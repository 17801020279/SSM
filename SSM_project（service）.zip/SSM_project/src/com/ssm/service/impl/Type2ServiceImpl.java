package com.ssm.service.impl;

import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.Type2Mapper;
import com.ssm.mapper.Type2MapperCustom;
import com.ssm.po.Type2Custom;
import com.ssm.service.Type2Service;

public class Type2ServiceImpl implements Type2Service{
	
	@Resource(name="type2MapperCustom")
	private Type2MapperCustom type2MapperCustom;
	
	@Resource(name="type2Mapper")
	private Type2Mapper type2Mapper;

	@Override
	public Type2Custom SelectByName(String name) throws Exception {
		List<Type2Custom> list = type2MapperCustom.SelectByName(name);
		Type2Custom type2Custom = list.get(0);
		return type2Custom;
	}

}
