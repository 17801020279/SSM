package com.ssm.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import com.ssm.mapper.Type1Mapper;
import com.ssm.mapper.Type1MapperCustom;
import com.ssm.po.Type1Custom;
import com.ssm.po.Type2Custom;
import com.ssm.service.Type1Service;

public class Type1ServiceImpl implements Type1Service{
	
	@Resource(name="type1MapperCustom")
	private Type1MapperCustom type1MapperCustom;
	
	@Resource(name="type1Mapper")
	private Type1Mapper type1Mapper;

	@Override
	public List<Type1Custom> DemandAndService1() throws Exception {
		List<Type1Custom> type1list = type1MapperCustom.DemandAndService1();
		return type1list;
	}
	
	@Override
	public List<String> DemandAndService2(String name) throws Exception {
		List<Type1Custom> type1list = type1MapperCustom.DemandAndService2(name);
		Type1Custom type1Custom = type1list.get(0);
		List<Type2Custom> type2Custom = type1Custom.getType2Customlist();
		// 二级类型的名称列表
		List<String> type2NameList = new ArrayList<String>();
		for(int i = 0; i<type2Custom.size(); i++){
			type2NameList.add(type2Custom.get(i).getTypeName());
		}
		return type2NameList;
	}

}
