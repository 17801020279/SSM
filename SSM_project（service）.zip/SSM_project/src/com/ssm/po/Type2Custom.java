package com.ssm.po;

public class Type2Custom extends Type2 {

}
