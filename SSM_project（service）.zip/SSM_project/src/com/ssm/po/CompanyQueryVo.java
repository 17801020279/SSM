package com.ssm.po;
/**
 * 用户的包装对象类
 * @author lenovo
 *
 */
public class CompanyQueryVo {
	
	private Company company;
	
	//为了系统可扩展性，对原始生成的po进行扩展
	private CompanyCustom companyCustom;

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	public CompanyCustom getCompanyCustom() {
		return companyCustom;
	}

	public void setCompanyCustom(CompanyCustom companyCustom) {
		this.companyCustom = companyCustom;
	}
	
	



}
