package com.ssm.po;

public class Type1QueryVo {
	
	private Type1 type1;
	private Type1Custom type1Custom;
	
	public Type1 getType1() {
		return type1;
	}
	public void setType1(Type1 type1) {
		this.type1 = type1;
	}
	public Type1Custom getType1Custom() {
		return type1Custom;
	}
	public void setType1Custom(Type1Custom type1Custom) {
		this.type1Custom = type1Custom;
	}

}
