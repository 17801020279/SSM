package com.ssm.po;
/**
 * 投标的扩展类
 * @author lenovo
 *
 */
public class BidCustom extends Bid{
	//

}
