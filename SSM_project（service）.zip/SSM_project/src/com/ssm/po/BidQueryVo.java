package com.ssm.po;
/**
 * 投标的包装对象类
 * @author lenovo
 *
 */
public class BidQueryVo {
	
	 private Bid bid;
	 
	 private BidCustom bidCustom;

	public Bid getBid() {
		return bid;
	}

	public void setBid(Bid bid) {
		this.bid = bid;
	}

	public BidCustom getBidCustom() {
		return bidCustom;
	}

	public void setBidCustom(BidCustom bidCustom) {
		this.bidCustom = bidCustom;
	}
	 
	 
	
	



}
