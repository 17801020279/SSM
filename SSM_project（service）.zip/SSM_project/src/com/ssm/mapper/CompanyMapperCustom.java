package com.ssm.mapper;

import java.util.List;


import com.ssm.po.CompanyCustom;
import com.ssm.po.CompanyQueryVo;


public interface CompanyMapperCustom {

		//登录
		public List<CompanyCustom> companyLogin(CompanyCustom CompanyCustom) throws Exception;

		//注册
		public void companyRegister(CompanyCustom  companyCustom)throws Exception;
		
		//修改服务商信息
		public void updateCompany(CompanyQueryVo CompanyQueryVo)throws Exception;
		
		// 服务商名称查重
		public List<CompanyCustom> checkCompanyName(String companyName) throws Exception;
		
		

}
