package test;

import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.Type1MapperCustom;
import com.ssm.po.Type1Custom;
import com.ssm.po.Type1QueryVo;
import com.ssm.po.Type2Custom;

public class Type1MapperTest {
	private ApplicationContext applicationContext;
	private Type1MapperCustom type1MapperCustom;
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		type1MapperCustom= (Type1MapperCustom) applicationContext.getBean("type1MapperCustom");
	}
	 

	//
	@Test
	public void type1AndType2ListTest() throws Exception{
		List<Type1Custom> type1Custom = type1MapperCustom.DemandAndService1();
		System.out.println(type1Custom);
		
		
	}
	
	
	
	

}
