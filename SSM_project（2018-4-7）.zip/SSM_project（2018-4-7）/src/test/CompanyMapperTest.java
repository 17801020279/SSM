package test;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.CompanyMapperCustom;
import com.ssm.mapper.UserMapperCustom;
import com.ssm.po.CompanyCustom;
import com.ssm.po.User;
import com.ssm.po.UserCustom;

public class CompanyMapperTest {
	private ApplicationContext applicationContext;
	private CompanyMapperCustom  companyMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		companyMapperCustom= (CompanyMapperCustom) applicationContext.getBean("companyMapperCustom");
	}
	 
	//注册
	/*@Test
	public void registTest() throws Exception{
		CompanyCustom companyCustom=new CompanyCustom();
		companyCustom.setComName("999");
		companyCustom.setComPass("999");
		if (companyMapperCustom.checkCompanyName(companyCustom.getComName()) != null) {
			System.out.println(companyCustom.getComName()+"用户已存在，注册失败");
		}else {
			companyMapperCustom.companyRegister(companyCustom);
		System.out.println(companyCustom.getComName()+"company注册成功");
		}
	}*/
	
	
	//登录
	@Test
	public void loginTest() throws Exception{
		//companyMapperCustom.loginCompany("123","123");
		System.out.println(companyMapperCustom);
		System.out.println("company登录成功");
	}
	
	
	
	

}
