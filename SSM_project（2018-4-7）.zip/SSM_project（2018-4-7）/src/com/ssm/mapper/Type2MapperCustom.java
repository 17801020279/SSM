package com.ssm.mapper;

import java.util.List;

import com.ssm.po.ServiceCustom;
import com.ssm.po.Type2Custom;

public interface Type2MapperCustom {
	
	// 根据名称查询type2
	public List<Type2Custom> SelectByName(String name) throws Exception;
	
	
	//6.查询服务商发布服务信息
   public List<Type2Custom> findCompanyAndServices(int comId ) throws Exception;
	
}
