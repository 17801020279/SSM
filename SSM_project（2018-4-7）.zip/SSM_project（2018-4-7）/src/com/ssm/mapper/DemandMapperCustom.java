package com.ssm.mapper;

import java.util.List;

import com.ssm.po.DemandCustom;
import com.ssm.po.UserCustom;


public interface DemandMapperCustom {
	
	//1.用户发布需求
	public void addDemand(DemandCustom  demandCustom) throws Exception;
	
	//2.删除需求
	public void deleteDemandById(int demandId) throws Exception;
	
	//3.更新需求
	public void updateDemandById(DemandCustom  demandCustom) throws Exception;
	
	//4.根据需求id查询需求
	public List<DemandCustom>  findDemandById(int demandId) throws Exception;
	
	//5.根据需求demandTitle模糊查询需求
	public List<DemandCustom> findDemandByDemandTitle(String demandTitle) throws Exception;
	
	//5.根据需求demandTitle模糊查询需求
	public List<DemandCustom> findDemandByDemandTitleResultMap(String demandTitle) throws Exception;
	
	//6.查询用户发布需求信息
	public List<UserCustom> findUserAndDemandsResultMap(int userId ) throws Exception;
	
	//7.根据demandType查询需求
	public List<DemandCustom> findDemandByType(int demandType) throws Exception;
	
	//8.返回最新插入的前10条记录
	public List<DemandCustom> findDemandNew() throws Exception;

}
