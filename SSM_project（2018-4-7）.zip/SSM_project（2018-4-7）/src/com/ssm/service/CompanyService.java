package com.ssm.service;

import com.ssm.po.CompanyCustom;

public interface CompanyService {
	
	// 公司注册
	public CompanyCustom companyRegister(CompanyCustom companyCustom) throws Exception;
	// 公司登录
	public CompanyCustom companyLogin(CompanyCustom companyCustom) throws Exception;

}
