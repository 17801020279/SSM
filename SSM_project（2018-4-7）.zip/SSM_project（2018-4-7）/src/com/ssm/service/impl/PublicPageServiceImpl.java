package com.ssm.service.impl;

import com.ssm.service.PublicPageService;

public class PublicPageServiceImpl implements PublicPageService {

}
