package com.ssm.service;

import com.ssm.po.UserCustom;

public interface UserService {
	
	// 会员注册
	public UserCustom userRegister(UserCustom userCustom) throws Exception;
	// 会员登录
	public UserCustom userLogin(UserCustom userCustom) throws Exception;
	
}