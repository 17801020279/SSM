package com.ssm.po;

import java.util.List;

public class Type2Custom extends Type2 {

    private List<ServiceCustom> serviceCustomList;
    
	public List<ServiceCustom> getServiceCustomList() {
		return serviceCustomList;
	}

	public void setServiceCustomList(List<ServiceCustom> serviceCustomList) {
		this.serviceCustomList = serviceCustomList;
	}
    
	
	
	
    

}
