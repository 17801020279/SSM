package com.ssm.po;

import java.util.List;

/**
 * 用户的扩展类
 * @author lenovo
 *
 */
public class CompanyCustom extends Company{
	
	private List<ServiceCustom> serviceCustomList;
	
	private List<Type1Custom> type1CustomList ;

	public List<ServiceCustom> getServiceCustomList() {
		return serviceCustomList;
	}
	
	public void setServiceCustomList(List<ServiceCustom> serviceCustomList) {
		this.serviceCustomList = serviceCustomList;
	}

	public List<Type1Custom> getType1CustomList() {
		return type1CustomList;
	}

	public void setType1CustomList(List<Type1Custom> type1CustomList) {
		this.type1CustomList = type1CustomList;
	}
	
	
	

}
