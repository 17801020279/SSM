package com.ssm.po;
/**
 * Type2二级菜单的包装对象类
 *
 */
public class Type2QueryVo {
	
	private Type2 type2;
	
	private Type2Custom type2Custom;
	

	public Type2 getType2() {
		return type2;
	}

	public void setType2(Type2 type2) {
		this.type2 = type2;
	}

	public Type2Custom getType2Custom() {
		return type2Custom;
	}

	public void setType2Custom(Type2Custom type2Custom) {
		this.type2Custom = type2Custom;
	}
	
}
