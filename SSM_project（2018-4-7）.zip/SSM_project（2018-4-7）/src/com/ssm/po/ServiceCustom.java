package com.ssm.po;
/**
 * 服务商的扩展类
 * @author lenovo
 *
 */
public class ServiceCustom extends Service{
	
	private String comName;
	 
    private String first_type_name;
 
    private String sec_type_Nmae;
    

	public String getComName() {
		return comName;
	}

	public void setComName(String comName) {
		this.comName = comName;
	}

	public String getFirst_type_name() {
		return first_type_name;
	}

	public void setFirst_type_name(String first_type_name) {
		this.first_type_name = first_type_name;
	}

	public String getSec_type_Nmae() {
		return sec_type_Nmae;
	}

	public void setSec_type_Nmae(String sec_type_Nmae) {
		this.sec_type_Nmae = sec_type_Nmae;
	}

}
