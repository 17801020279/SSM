package com.ssm.po;
/**
 * 服务商的包装对象类
 * @author lenovo
 *
 */
public class ServiceQueryVo {
	
	private Service service;
	
	//为了系统可扩展性，对原始生成的po进行扩展
	private ServiceCustom serviceCustom;
	

	public Service getService() {
		return service;
	}

	public void setService(Service service) {
		this.service = service;
	}

	public ServiceCustom getServiceCustom() {
		return serviceCustom;
	}

	public void setServiceCustom(ServiceCustom serviceCustom) {
		this.serviceCustom = serviceCustom;
	}


}
