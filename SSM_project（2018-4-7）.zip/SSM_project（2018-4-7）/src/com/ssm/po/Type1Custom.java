package com.ssm.po;

import java.util.List;

public class Type1Custom extends Type1 {
	
	private List<Type2Custom> type2Customlist;

	public List<Type2Custom> getType2Customlist() {
		return type2Customlist;
	}

	public void setType2Customlist(List<Type2Custom> type2Customlist) {
		this.type2Customlist = type2Customlist;
	}

}
