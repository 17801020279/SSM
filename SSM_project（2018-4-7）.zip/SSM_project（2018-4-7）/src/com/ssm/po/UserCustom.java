package com.ssm.po;

import java.util.List;


/**
 * 用户的扩展类
 * @author lenovo
 *
 */
public class UserCustom extends User{
	
	
	private List<DemandCustom> DemandCustomList;

	public List<DemandCustom> getDemandCustomList() {
		return DemandCustomList;
	}

	public void setDemandCustomList(List<DemandCustom> demandCustomList) {
		DemandCustomList = demandCustomList;
	}

	

}
