package com.ssm.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ssm.po.CompanyCustom;
import com.ssm.po.ServiceCustom;
import com.ssm.po.Type1Custom;
import com.ssm.po.Type2Custom;
import com.ssm.service.CompanyService;
import com.ssm.service.ServiceService;
import com.ssm.service.Type1Service;
import com.ssm.service.Type2Service;

@Controller //公司的Controller
@RequestMapping(value="/company")
public class CompanyController {
	
	@Resource(name="companyService")
	public CompanyService companyService;
	@Resource(name="type1Service")
	private Type1Service type1Service;
	@Resource(name="type2Service")
	private Type2Service type2Service;
	@Resource(name="serviceService")
	private ServiceService serviceService;
	
	// 公司注册提交后的页面
	@RequestMapping(value="/companyRegisterSubmit.action")
	public String companyRegisterSubmit(HttpSession session, Model model, CompanyCustom companyCustom) throws Exception {
		CompanyCustom companyCustom1 = companyService.companyRegister(companyCustom);
		if(companyCustom1==null) {
			String loginError = "输入的公司已注册，请直接登录";
			model.addAttribute("loginError",loginError);
			return "/jsp/register.jsp";
		}
		else {
			return "/jsp/login.jsp";
		}
	}
	
	
	// 公司登录提交后的页面
	@RequestMapping(value="/companyLoginSubmit.action")
	public String companyLoginSubmit(HttpSession session, Model model, CompanyCustom companyCustom) throws Exception {
		CompanyCustom companyCustom1 = companyService.companyLogin(companyCustom);
		if(companyCustom1==null) {
			String loginError = "输入的用户名或密码错误";
			model.addAttribute("loginError",loginError);
			return "/jsp/login.jsp";
		}
		else {
			session.setAttribute("companyCustom", companyCustom1);
			return "/jsp/mainPage.jsp";
		}
	}
	
	
	// 公司发布服务，一级需求的list
	@RequestMapping(value="/companyAddService.action")
	public String companyAddService(HttpSession session, Model model) throws Exception {
			List<Type1Custom> type1list = type1Service.DemandAndService1();
			model.addAttribute("type1list",type1list);
			return "/jsp/send_service.jsp";
	}
	
	
	// 公司发布服务，二级需求的list
	@RequestMapping(value="/companyAddService2.action")
	public @ResponseBody List<String> companyAddService2(String type1) throws Exception {
		return type1Service.DemandAndService2(type1);
	}
	
	
	// 会员发布需求提交后的界面
	@RequestMapping(value="/companyReleaseServiceSubmit.action")
	public String companyReleaseServiceSubmit(HttpSession session, Model model, ServiceCustom serviceCustom, String type2) throws Exception {
		CompanyCustom companyCustom = (CompanyCustom) session.getAttribute("companyCustom");
		Type2Custom type2Custom = type2Service.SelectByName(type2);
		serviceCustom.setServiceType(type2Custom.getSecTypeId());
		ServiceCustom serviceCustom1 = serviceService.companyAddService(companyCustom, serviceCustom, type2);
		model.addAttribute("serviceCustom",serviceCustom1);
		return "/jsp/mainPage.jsp";
	}
	
	

}
