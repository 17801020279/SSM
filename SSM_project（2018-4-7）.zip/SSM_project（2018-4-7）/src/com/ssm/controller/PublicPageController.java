package com.ssm.controller;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.ssm.po.DemandCustom;
import com.ssm.service.DemandService;
import com.ssm.service.PublicPageService;

@Controller //公开页面的Controller
@RequestMapping(value="/publicPage")
public class PublicPageController {
	
	@Resource(name="publicPageService")
	private PublicPageService publicPageService;
	@Resource(name="demandService")
	private DemandService demandService;
	
	// 首页
	@RequestMapping(value="/mainPage.action")
	public String mainPage(Model model) throws Exception {
		List<DemandCustom> list = demandService.findLatestDemand();
		model.addAttribute("list", list);
		return "/jsp/mainPage.jsp";
	}
	
	// 注册的页面
	@RequestMapping(value="/Register.action")
	public String Register() throws Exception {
		return "/jsp/register.jsp";
	}
	
	// 登录的页面
	@RequestMapping(value="/Login.action")
	public String Login() throws Exception {
		return "/jsp/login.jsp";
	}
	
	// 根据demandTitle模糊查询需求提交后的页面
	@RequestMapping(value="/fuzzySearchDemandSubmit.action")
	public String fuzzySearchDemandSubmit(Model model, String demandTitle) throws Exception {
		List<DemandCustom> fuzzylist = demandService.findDemandByDemandTitle(demandTitle);
		model.addAttribute("fuzzylist", fuzzylist);
		return null;
	}

}
