package test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.DemandMapperCustom;
import com.ssm.po.DemandCustom;

public class DemandMapperTest {
	private ApplicationContext applicationContext;
	private DemandMapperCustom demandMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		demandMapperCustom= (DemandMapperCustom) applicationContext.getBean("demandMapperCustom");
	}
	 
	//1.用户发布需求
	@Test
	public void addDemandTest() throws Exception{
		DemandCustom demandCustom=new DemandCustom();
		//user.setUserId(2);
		demandCustom.setUserId(2);
		demandCustom.setDemandTitle("用户发布的第488条需求");
		demandCustom.setDemandDetail("这是用户发布的第488条需求");
		demandCustom.setDemandType(1);
		Date date = new Date();
		demandCustom.setDemandTime(date);
		demandMapperCustom.addDemand(demandCustom);
	}
	
	
	//2.删除
	/*@Test
	public void deleteDemandByIdTest() throws Exception{
		demandMapperCustom.deleteDemandById(7);
	}*/
	
	
	//3.update
	/*@Test
	public void updateDemandByIdTest() throws Exception{
		DemandCustom demandCustom2=new DemandCustom();
		demandCustom2.setDemandId(9);
		demandCustom2.setDemandTitle("用户发布的第99999999999999999条需求");
		demandCustom2.setDemandDetail("这是用户发布的第9999条需求");
		demandCustom2.setDemandType(2);
		Date date1 = new Date();
		demandCustom2.setDemandTime(date1);
		demandMapperCustom.updateDemandById(demandCustom2);
	}*/
			
	
	//4.根据id查询
		/*@Test
		public void findDemandByIdTest() throws Exception{
			demandMapperCustom.findDemandById(1);
		}
		*/
		
	//5.findDemandByDemandTitle
		@Test
		public void findDemandByDemandTitleTset() throws Exception{
			List<DemandCustom> demandCustoms=demandMapperCustom.findDemandByDemandTitle("33");
			System.out.println(demandCustoms);		
		}
		
		
		
	//5.findDemandByDemandTitleResultMap
		@Test
		public void findDemandByDemandTitleResultMapTset() throws Exception{
			List<DemandCustom> demandCustoms=demandMapperCustom.findDemandByDemandTitle("33");
			System.out.println(demandCustoms);		
		}
		
	//6.findUserAndDemands
		@Test
		public void findUserAllDemandsTest() throws Exception{
			
			List<DemandCustom> demandCustoms = demandMapperCustom.findUserAllDemands(1);
			System.out.println(demandCustoms);
		}
		
		
		//7.findDemandByType
		/*@Test
		public void findDemandByTypeTest() throws Exception{
			
			demandMapperCustom.findDemandByType(3);
		}*/
		
		
		//8.findDemandNew
		@Test
		public void findDemandNewTest() throws Exception{
			
			List<DemandCustom> demandCustoms=demandMapperCustom.findDemandNew();
			System.out.println(demandCustoms);
		}

		
		
		
		
		
		
		
	
	
	

}
