package com.ssm.mapper;

import java.util.List;
import org.apache.ibatis.annotations.Param;

import com.ssm.po.Type2;
import com.ssm.po.Type2Example;

public interface Type2Mapper {
    int countByExample(Type2Example example);

    int deleteByExample(Type2Example example);

    int deleteByPrimaryKey(Integer secTypeId);

    int insert(Type2 record);

    int insertSelective(Type2 record);

    List<Type2> selectByExample(Type2Example example);

    Type2 selectByPrimaryKey(Integer secTypeId);

    int updateByExampleSelective(@Param("record") Type2 record, @Param("example") Type2Example example);

    int updateByExample(@Param("record") Type2 record, @Param("example") Type2Example example);

    int updateByPrimaryKeySelective(Type2 record);

    int updateByPrimaryKey(Type2 record);
}