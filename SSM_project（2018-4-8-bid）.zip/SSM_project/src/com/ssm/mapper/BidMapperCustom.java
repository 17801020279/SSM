package com.ssm.mapper;

import java.util.List;

import com.ssm.po.BidCustom;

public interface BidMapperCustom  {

	//1.添加投标
	public void addBid(BidCustom bidCustom) throws Exception;
	
	//2.更新投标状态
	//public void updateBidState(BidCustom bidCustom) throws Exception;
	
	//3.删除投标
	//public void deleteBidById(int bidId) throws Exception;
		
	//4.findUserAllBids
	public List<BidCustom> findUserAllBids(int userId) throws Exception;

	public List<BidCustom> findCompanyAllBids(int comId)throws Exception;

}
