package com.ssm.mapper;

import com.ssm.po.OrderCustom;

public interface OrderMapperCustom {
	
	//1.添加order
	public void addOrder(OrderCustom orderCustom) throws Exception;
	
	
	//2.删除order
	public void deleteOrderById(int orderId) throws Exception;



		
		

}
