package com.ssm.service;

import com.ssm.po.CompanyCustom;
import com.ssm.po.ServiceCustom;

public interface ServiceService {
	
	// 公司发布服务
	public ServiceCustom companyAddService(CompanyCustom companyCustom, ServiceCustom serviceCustom, String type2) throws Exception;

}
