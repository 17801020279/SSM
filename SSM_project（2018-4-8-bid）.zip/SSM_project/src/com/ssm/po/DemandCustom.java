package com.ssm.po;


/**
 * 需求实体的扩展类
 *
 */
public class DemandCustom extends Demand {
	//添加新属性
	
	 private String userName;
	 
	 private String first_type_name;
	 
	 private String sec_type_Name;
	 
	 private Type2Custom type2Custom;

	 public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getFirst_type_name() {
		return first_type_name;
	}

	public void setFirst_type_name(String first_type_name) {
		this.first_type_name = first_type_name;
	}

	
	public String getSec_type_Name() {
		return sec_type_Name;
	}
	
	public void setSec_type_Name(String sec_type_Name) {
		this.sec_type_Name = sec_type_Name;
	}

	public Type2Custom getType2Custom() {
		return type2Custom;
	}

	public void setType2Custom(Type2Custom type2Custom) {
		this.type2Custom = type2Custom;
	}
	 
	
	 
	 
	

}
