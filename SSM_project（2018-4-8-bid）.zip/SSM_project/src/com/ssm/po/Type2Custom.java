package com.ssm.po;


public class Type2Custom extends Type2 {

	private Type1Custom type1Custom;

	public Type1Custom getType1Custom() {
		return type1Custom;
	}

	public void setType1Custom(Type1Custom type1Custom) {
		this.type1Custom = type1Custom;
	}
	
	
}
