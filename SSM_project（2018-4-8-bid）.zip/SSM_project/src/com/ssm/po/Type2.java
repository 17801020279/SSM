package com.ssm.po;

public class Type2 {
    private Integer secTypeId;

    private String typeName;

    private Integer typeFirstId;

    public Integer getSecTypeId() {
        return secTypeId;
    }

    public void setSecTypeId(Integer secTypeId) {
        this.secTypeId = secTypeId;
    }

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName == null ? null : typeName.trim();
    }

    public Integer getTypeFirstId() {
        return typeFirstId;
    }

    public void setTypeFirstId(Integer typeFirstId) {
        this.typeFirstId = typeFirstId;
    }
}