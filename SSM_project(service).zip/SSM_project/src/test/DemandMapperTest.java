package test;

import java.util.Date;
import java.util.List;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.DemandMapperCustom;
import com.ssm.po.Demand;
import com.ssm.po.DemandCustom;
import com.ssm.po.DemandQueryVo;
import com.ssm.po.User;

public class DemandMapperTest {
	private ApplicationContext applicationContext;
	private DemandMapperCustom demandMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		demandMapperCustom= (DemandMapperCustom) applicationContext.getBean("demandMapperCustom");
	}
	 
	//用户发布需求
	@Test
	public void addDemandTest() throws Exception{
		DemandCustom demandCustom=new DemandCustom();
		User user = new User();
		//user.setUserId(2);
		demandCustom.setUserId(2);
		demandCustom.setDemandTitle("用户发布的第47条需求");
		demandCustom.setDemandDetail("这是用户发布的第47条需求");
		demandCustom.setDemandType(1);
		Date date = new Date();
		demandCustom.setDemandTime(date);
		demandMapperCustom.addDemand(demandCustom);
	}
	
	
	//删除
	@Test
	public void deleteDemandByIdTest() throws Exception{
		demandMapperCustom.deleteDemandById(7);
	}
	
	
	//update
	@Test
	public void updateDemandByIdTest() throws Exception{
		DemandQueryVo demandQueryVo=new DemandQueryVo();
		DemandCustom demandCustom2=new DemandCustom();
		demandCustom2.setDemandId(9);
		demandCustom2.setDemandTitle("用户发布的第99999999999999999条需求");
		demandCustom2.setDemandDetail("这是用户发布的第9999条需求");
		demandCustom2.setDemandType(2);
		/*Date date1 = new Date();
		demandCustom2.setDemandTime(date1);*/
		demandQueryVo.setDemandCustom(demandCustom2);
		demandMapperCustom.updateDemandById(demandQueryVo);
	}
			
	
	//根据id查询
		@Test
		public void findDemandByIdTest() throws Exception{
			demandMapperCustom.findDemandById(1);
		}
		
		
		//findDemandByDemandTitle
		@Test
		public void findDemandByDemandTitleTset() throws Exception{
			demandMapperCustom.findDemandByDemandTitle("47");
		}
		
		
		//findUserAndDemands
		@Test
		public void findUserAndDemandsResultMapTest() throws Exception{
			
			demandMapperCustom.findUserAndDemandsResultMap(1);
		}
		
		
		//findDemandByType
		@Test
		public void findDemandByTypeTest() throws Exception{
			
			demandMapperCustom.findDemandByType(3);
		}
		
		
		
		
		
		
	
	
	

}
