package test;

import java.util.Date;
import java.util.List;

import javax.mail.search.DateTerm;
import javax.print.attribute.standard.DateTimeAtCompleted;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.DemandMapperCustom;
import com.ssm.mapper.ServiceMapperCustom;
import com.ssm.po.Company;
import com.ssm.po.CompanyCustom;
import com.ssm.po.Demand;
import com.ssm.po.DemandCustom;
import com.ssm.po.DemandQueryVo;
import com.ssm.po.ServiceCustom;
import com.ssm.po.ServiceQueryVo;
import com.ssm.po.User;

public class ServiceMapperTest {
	private ApplicationContext applicationContext;
	private ServiceMapperCustom serviceMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		serviceMapperCustom= (ServiceMapperCustom) applicationContext.getBean("serviceMapperCustom");
	}
	 
	//用户发布需求
	@Test
	public void addServiceTest() throws Exception{
		ServiceCustom serviceCustom=new ServiceCustom();
		/*Company company = new Company();
		company.setComId(1);*/
		serviceCustom.setComId(3);
		serviceCustom.setServiceTitle("第33条服务");
		serviceCustom.setServiceType(3);
		serviceCustom.setServiceDetail("这是第33条服务");
		Date date = new Date();
		serviceCustom.setServiceTime(date);
		serviceMapperCustom.addService(serviceCustom);
	}
	
	
	//删除
	@Test
	public void deleteServiceByIdTest() throws Exception{
		serviceMapperCustom.deleteServiceById(4);
	}
	
	
	//update
	@Test
	public void updateServiceByIdTest() throws Exception{
		ServiceQueryVo serviceQueryVo=new ServiceQueryVo();
		ServiceCustom serviceCustom=new ServiceCustom();
		serviceCustom.setServiceId(3);
		serviceCustom.setServiceTitle("第333条服务");
		serviceCustom.setServiceDetail("这是第333条服务");
		serviceCustom.setServiceType(1);
		Date date = new Date();
		serviceCustom.setServiceTime(date);
		serviceQueryVo.setServiceCustom(serviceCustom);
		serviceMapperCustom.updateServiceById(serviceQueryVo);
	}
			
	
	//根据id查询
		@Test
		public void findServiceByIdTest() throws Exception{
			serviceMapperCustom.findServiceById(1);
		}
		
		
		
		@Test
		public void findserviceByServiceTitleTset() throws Exception{
			serviceMapperCustom.findServiceByServiceTitle("3");
		}
		
	
		
		@Test
		public void findCompanyAndServicesResultMapTest() throws Exception{
			System.out.println("00000000000000000000000");
			List<CompanyCustom> serviceCustomList=  serviceMapperCustom.findCompanyAndServicesResultMap(3);
		}
		
		
		@Test
		public void findServiceByTypeTest() throws Exception{
			System.out.println("11111111111111111");
			List<ServiceCustom> serviceCustomList=serviceMapperCustom.findServiceByType(1);
		}
		
		
		
		
		
		
	
	
	

}
