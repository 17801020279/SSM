package com.ssm.mapper;




public interface OrderMapperCustom {
	

		
		

}
