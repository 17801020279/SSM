package com.ssm.mapper;

import java.util.List;

import com.ssm.po.CompanyCustom;
import com.ssm.po.ServiceCustom;
import com.ssm.po.ServiceQueryVo;
import com.ssm.po.Type1QueryVo;


public interface ServiceMapperCustom {
	
    	//1.服务商发布服务
		public void addService(ServiceCustom  serviceCustom) throws Exception;
		
		//2.删除服务
		public void deleteServiceById(int serviceId) throws Exception;
		
		//3.更新服务
		public void updateServiceById(ServiceQueryVo serviceQueryVo) throws Exception;
		
		//4.根据服务id查询服务
		public List<ServiceCustom>  findServiceById(int serviceId) throws Exception;
		
		//5.根据服务serviceTitle模糊查询
		public List<ServiceCustom> findServiceByServiceTitle(String serviceTitle) throws Exception;
		
		//6.查询服务商发布服务信息
		public List<CompanyCustom> findCompanyAndServicesResultMap(int comId ) throws Exception;
		
		//7.根据serviceType查询服务
		public List<ServiceCustom> findServiceByType(int serviceType) throws Exception;

		
		

}
