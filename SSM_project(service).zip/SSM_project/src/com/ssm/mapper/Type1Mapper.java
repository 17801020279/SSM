package com.ssm.mapper;

import com.ssm.po.Type1;
import com.ssm.po.Type1Example;
import java.util.List;
import org.apache.ibatis.annotations.Param;

public interface Type1Mapper {
    int countByExample(Type1Example example);

    int deleteByExample(Type1Example example);

    int deleteByPrimaryKey(Integer firstTypeId);

    int insert(Type1 record);

    int insertSelective(Type1 record);

    List<Type1> selectByExample(Type1Example example);

    Type1 selectByPrimaryKey(Integer firstTypeId);

    int updateByExampleSelective(@Param("record") Type1 record, @Param("example") Type1Example example);

    int updateByExample(@Param("record") Type1 record, @Param("example") Type1Example example);

    int updateByPrimaryKeySelective(Type1 record);

    int updateByPrimaryKey(Type1 record);
}