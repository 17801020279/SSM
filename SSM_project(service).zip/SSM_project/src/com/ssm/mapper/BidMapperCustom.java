package com.ssm.mapper;



public interface BidMapperCustom {

		
		

}
