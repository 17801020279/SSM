package com.ssm.po;

import java.util.List;

/**
 * Type1一级菜单的扩展类
 * @author lenovo
 *
 */
public class Type1Custom extends Type1{
	
	private List<Type2Custom> type2Customlist;

	public List<Type2Custom> getType2Customlist() {
		return type2Customlist;
	}

	public void setType2Customlist(List<Type2Custom> type2Customlist) {
		this.type2Customlist = type2Customlist;
	}
	

}
