package com.ssm.po;
/**
 * 服务商的扩展类
 * @author lenovo
 *
 */
public class ServiceCustom extends Service{
	
	private String com_name;
	
	private String serviceType_name;

	public String getCom_name() {
		return com_name;
	}

	public void setCom_name(String com_name) {
		this.com_name = com_name;
	}

	public String getServiceType_name() {
		return serviceType_name;
	}

	public void setServiceType_name(String serviceType_name) {
		this.serviceType_name = serviceType_name;
	}
	
	
	

}
