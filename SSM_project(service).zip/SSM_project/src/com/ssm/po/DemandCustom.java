package com.ssm.po;
/**
 * 需求实体的扩展类
 * @author lenovo
 *
 */
public class DemandCustom extends Demand {
	

}
