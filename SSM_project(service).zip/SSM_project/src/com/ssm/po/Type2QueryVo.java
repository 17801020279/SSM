package com.ssm.po;
/**
 * Type2二级菜单的包装对象类
 * @author lenovo
 *
 */
public class Type2QueryVo {
	
	private Type2 type2;
	
	private Type2Custom type1Custom;

	public Type2 getType2() {
		return type2;
	}

	public void setType2(Type2 type2) {
		this.type2 = type2;
	}

	public Type2Custom getType1Custom() {
		return type1Custom;
	}

	public void setType1Custom(Type2Custom type1Custom) {
		this.type1Custom = type1Custom;
	}
	
	
	


}
