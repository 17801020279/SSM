package com.ssm.po;

import java.util.List;

/**
 * 用户的扩展类
 * @author lenovo
 *
 */
public class CompanyCustom extends Company{
	
	private List<ServiceCustom> serviceCustomList;

	public List<ServiceCustom> getServiceCustomList() {
		return serviceCustomList;
	}

	public void setServiceCustomList(List<ServiceCustom> serviceCustomList) {
		this.serviceCustomList = serviceCustomList;
	}
	
	

}
