package com.ssm.po;
/**
 * 订单的扩展类
 * @author lenovo
 *
 */
public class OrderCustom extends Order{
	//

}
