package test;

import java.util.Date;

import org.junit.Before;
import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ssm.mapper.DemandMapperCustom;
import com.ssm.po.Demand;
import com.ssm.po.DemandCustom;
import com.ssm.po.User;

public class DemandMapperTest {
	private ApplicationContext applicationContext;
	private DemandMapperCustom demandMapperCustom;
	
	@Before
	public void setUp(){
		applicationContext=(ApplicationContext) new ClassPathXmlApplicationContext("classpath:spring/applicationContext-dao.xml");
		demandMapperCustom= (DemandMapperCustom) applicationContext.getBean("demandMapperCustom");
	}
	 
	//用户发布需求
	@Test
	public void addDemandTest() throws Exception{
		DemandCustom demandCustom=new DemandCustom();
		User user = new User();
		user.setUserId(2);
		//demandCustom.setUserId(2);
		demandCustom.setDemandTitle("用户发布的第33条需求");
		demandCustom.setDemandDetail("这是用户发布的第33条需求");
		demandCustom.setDemandType(1);
		Date date = new Date(2017,3,19);
		demandCustom.setDemandTime(date);
		demandMapperCustom.addDemand(demandCustom);
	}
	
	
	//用户模糊查询需求
		@Test
		public void findDemandByKeyWordTest() throws Exception{
			String keyWord="需求";
			demandMapperCustom.findDemandByKeyWord(keyWord);
		}
	
	

}
