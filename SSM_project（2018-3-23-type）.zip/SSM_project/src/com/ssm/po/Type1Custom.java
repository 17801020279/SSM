package com.ssm.po;
/**
 * Type1一级菜单的扩展类
 * @author lenovo
 *
 */
public class Type1Custom extends Type1{
	//

}
