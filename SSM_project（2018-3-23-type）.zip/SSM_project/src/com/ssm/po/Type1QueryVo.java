package com.ssm.po;

import java.util.List;

/**
 * Type1一级菜单的包装对象类
 * @author lenovo
 *
 */
public class Type1QueryVo {
	
	private Type1 type1;
	
	private Type1Custom type1Custom;
	
	private List<Type2Custom> type2Customs;
	
	public Type1 getType1() {
		return type1;
	}
	public void setType1(Type1 type1) {
		this.type1 = type1;
	}
	public Type1Custom getType1Custom() {
		return type1Custom;
	}
	public void setType1Custom(Type1Custom type1Custom) {
		this.type1Custom = type1Custom;
	}
	public List<Type2Custom> getType2Customs() {
		return type2Customs;
	}
	public void setType2Customs(List<Type2Custom> type2Customs) {
		this.type2Customs = type2Customs;
	}
	
	
	


}
