package com.ssm.po;
/**
 * Type2二级菜单的扩展类
 * @author lenovo
 *
 */
public class Type2Custom extends Type2{
	//

}
