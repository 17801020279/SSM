package com.ssm.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.ssm.po.UserCustom;
import com.ssm.po.UserQueryVo;


public interface ServiceMapperCustom {

		//登录
		public UserCustom loginUser(@Param("user_name")String user_name, @Param("user_pass")String user_pass) throws Exception;

		//注册
		public void registUser(UserCustom userCustom)throws Exception;
		
		//修改用户信息
		public UserCustom updateUser(UserQueryVo userQueryVo)throws Exception;
		
		// 用户名称查重
		public List<UserCustom> checkUsername(String userName) throws Exception;
		
		

}
