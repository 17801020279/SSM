package com.ssm.mapper;

import java.util.List;

import com.ssm.po.Type1Custom;
import com.ssm.po.Type1QueryVo;
import com.ssm.po.Type2Custom;

public interface Type1MapperCustom {
	
	//public List<Type2Custom> type2CustomList()  throws Exception;
	
	
	public List<Type1Custom> type1CustomList()  throws Exception;
	
	public List<Type1QueryVo> Type1QueryVoList()  throws Exception;
	

		
		
		

}
