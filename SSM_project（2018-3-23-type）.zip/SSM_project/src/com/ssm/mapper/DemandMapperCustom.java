package com.ssm.mapper;

import com.ssm.po.DemandCustom;
import com.ssm.po.DemandQueryVo;

public interface DemandMapperCustom {
	
	//用户发布需求
	public void addDemand(DemandCustom  demandCustom) throws Exception;
	
	//删除需求
	public void deleteDemandById(int demandId) throws Exception;
	
	//更新需求
	public DemandCustom updateDemandById(DemandQueryVo demandQueryVo) throws Exception;
	
	//根据需求id
	public DemandCustom  findDemandById(int demandId) throws Exception;
	
	//根据关键字模糊查询
	public DemandCustom findDemandByKeyWord(String keyWord) throws Exception;
	
	//
	
	
}
